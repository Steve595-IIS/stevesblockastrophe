/**
 * Pure Game Rules and Logic for Steve's Blockastrophe 8x8 Block Puzzle
 */

export const GRID_SIZE = 8;

export interface ColorDef {
  id: string;
  name: string;
  fill: string; // main color
  gradient: string; // tailwind gradient
  border: string;
  glow: string;
}

export const COLOR_PALETTE: ColorDef[] = [
  {
    id: 'blue',
    name: 'Electric Blue',
    fill: '#00d2ff',
    gradient: 'from-[#00f2fe] to-[#4facfe]',
    border: '#00c6ff',
    glow: 'rgba(0, 210, 255, 0.6)',
  },
  {
    id: 'purple',
    name: 'Bright Purple',
    fill: '#b827fc',
    gradient: 'from-[#e056fd] to-[#8c14fc]',
    border: '#ab18f0',
    glow: 'rgba(184, 39, 252, 0.6)',
  },
  {
    id: 'pink',
    name: 'Neon Pink',
    fill: '#ff2a85',
    gradient: 'from-[#ff758c] to-[#ff0844]',
    border: '#ff0f68',
    glow: 'rgba(255, 42, 133, 0.6)',
  },
  {
    id: 'orange',
    name: 'Sunset Orange',
    fill: '#ff7700',
    gradient: 'from-[#f9d423] to-[#ff4e50]',
    border: '#f35a00',
    glow: 'rgba(255, 119, 0, 0.6)',
  },
  {
    id: 'yellow',
    name: 'Sunny Yellow',
    fill: '#ffd600',
    gradient: 'from-[#ffe000] to-[#799f0c]',
    border: '#ffc107',
    glow: 'rgba(255, 214, 0, 0.6)',
  },
  {
    id: 'turquoise',
    name: 'Turquoise',
    fill: '#00f5d4',
    gradient: 'from-[#2af598] to-[#009efd]',
    border: '#00dcb8',
    glow: 'rgba(0, 245, 212, 0.6)',
  },
  {
    id: 'lime',
    name: 'Lime Green',
    fill: '#70e000',
    gradient: 'from-[#bbf73a] to-[#38ef7d]',
    border: '#5cc700',
    glow: 'rgba(112, 224, 0, 0.6)',
  },
  {
    id: 'coral',
    name: 'Coral Red',
    fill: '#ff3366',
    gradient: 'from-[#ff6b8b] to-[#ff2e63]',
    border: '#e61e53',
    glow: 'rgba(255, 51, 102, 0.6)',
  },
];

export interface ShapeTemplate {
  name: string;
  matrix: number[][];
  weight?: number; // selection frequency
}

export const SHAPE_TEMPLATES: ShapeTemplate[] = [
  // 1x1 Single Dot
  { name: '1x1 Dot', matrix: [[1]], weight: 2 },

  // 2-blocks
  { name: '2x1 Line H', matrix: [[1, 1]], weight: 3 },
  { name: '1x2 Line V', matrix: [[1], [1]], weight: 3 },

  // 3-blocks lines
  { name: '3x1 Line H', matrix: [[1, 1, 1]], weight: 3 },
  { name: '1x3 Line V', matrix: [[1], [1], [1]], weight: 3 },

  // 4-blocks lines
  { name: '4x1 Line H', matrix: [[1, 1, 1, 1]], weight: 2 },
  { name: '1x4 Line V', matrix: [[1], [1], [1], [1]], weight: 2 },

  // 5-blocks lines (occasional exciting clearers)
  { name: '5x1 Line H', matrix: [[1, 1, 1, 1, 1]], weight: 1 },
  { name: '1x5 Line V', matrix: [[1], [1], [1], [1], [1]], weight: 1 },

  // Squares
  { name: '2x2 Square', matrix: [[1, 1], [1, 1]], weight: 3 },
  { name: '3x3 Square', matrix: [[1, 1, 1], [1, 1, 1], [1, 1, 1]], weight: 1 },

  // 2x2 Mini L-corners (3 blocks)
  { name: 'Corner TL', matrix: [[1, 1], [1, 0]], weight: 2 },
  { name: 'Corner TR', matrix: [[1, 1], [0, 1]], weight: 2 },
  { name: 'Corner BL', matrix: [[1, 0], [1, 1]], weight: 2 },
  { name: 'Corner BR', matrix: [[0, 1], [1, 1]], weight: 2 },

  // 3x3 Classic L-shapes (5 blocks)
  {
    name: 'Big L 1',
    matrix: [
      [1, 0, 0],
      [1, 0, 0],
      [1, 1, 1],
    ],
    weight: 2,
  },
  {
    name: 'Big L 2',
    matrix: [
      [0, 0, 1],
      [0, 0, 1],
      [1, 1, 1],
    ],
    weight: 2,
  },
  {
    name: 'Big L 3',
    matrix: [
      [1, 1, 1],
      [1, 0, 0],
      [1, 0, 0],
    ],
    weight: 2,
  },
  {
    name: 'Big L 4',
    matrix: [
      [1, 1, 1],
      [0, 0, 1],
      [0, 0, 1],
    ],
    weight: 2,
  },

  // T-shapes (4 blocks)
  {
    name: 'T-Shape Down',
    matrix: [
      [1, 1, 1],
      [0, 1, 0],
    ],
    weight: 2,
  },
  {
    name: 'T-Shape Up',
    matrix: [
      [0, 1, 0],
      [1, 1, 1],
    ],
    weight: 2,
  },
  {
    name: 'T-Shape Right',
    matrix: [
      [1, 0],
      [1, 1],
      [1, 0],
    ],
    weight: 2,
  },
  {
    name: 'T-Shape Left',
    matrix: [
      [0, 1],
      [1, 1],
      [0, 1],
    ],
    weight: 2,
  },

  // Z and S shapes (4 blocks)
  {
    name: 'Z-Shape H',
    matrix: [
      [1, 1, 0],
      [0, 1, 1],
    ],
    weight: 2,
  },
  {
    name: 'S-Shape H',
    matrix: [
      [0, 1, 1],
      [1, 1, 0],
    ],
    weight: 2,
  },
  {
    name: 'Z-Shape V',
    matrix: [
      [0, 1],
      [1, 1],
      [1, 0],
    ],
    weight: 2,
  },
  {
    name: 'S-Shape V',
    matrix: [
      [1, 0],
      [1, 1],
      [0, 1],
    ],
    weight: 2,
  },

  // Cross / Plus (5 blocks)
  {
    name: 'Plus Shape',
    matrix: [
      [0, 1, 0],
      [1, 1, 1],
      [0, 1, 0],
    ],
    weight: 1,
  },
];

export interface Piece {
  id: string;
  name: string;
  matrix: number[][];
  color: ColorDef;
  cellCount: number;
}

/**
 * Creates an empty 10x10 board matrix
 */
export function createEmptyBoard(size: number = GRID_SIZE): (ColorDef | null)[][] {
  const board: (ColorDef | null)[][] = [];
  for (let r = 0; r < size; r++) {
    const row: (ColorDef | null)[] = [];
    for (let c = 0; c < size; c++) {
      row.push(null);
    }
    board.push(row);
  }
  return board;
}

/**
 * Checks if every single cell on the board is empty (null).
 */
export function isBoardCompletelyEmpty(
  board: (ColorDef | null)[][],
  size: number = GRID_SIZE
): boolean {
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (board[r][c] !== null) {
        return false;
      }
    }
  }
  return true;
}

/**
 * Generates an exciting, solvable pre-filled starting board with diverse clusters of colorful shapes.
 * Solvable and guaranteed to have space and valid placements for initial pieces.
 */
export function generatePreFilledBoard(
  size: number = GRID_SIZE,
  initialPieces?: Piece[]
): (ColorDef | null)[][] {
  let attempts = 0;
  while (attempts < 60) {
    attempts++;
    const board = createEmptyBoard(size);
    // Select 3 to 6 clusters of shapes
    const numClusters = 3 + Math.floor(Math.random() * 4);
    let totalPlacedCells = 0;

    for (let i = 0; i < numClusters; i++) {
      const template = SHAPE_TEMPLATES[Math.floor(Math.random() * SHAPE_TEMPLATES.length)];
      const color = COLOR_PALETTE[Math.floor(Math.random() * COLOR_PALETTE.length)];
      const rows = template.matrix.length;
      const cols = template.matrix[0].length;

      for (let trial = 0; trial < 15; trial++) {
        const r = Math.floor(Math.random() * (size - rows + 1));
        const c = Math.floor(Math.random() * (size - cols + 1));
        if (canPlacePiece(board, template.matrix, r, c, size)) {
          for (let pr = 0; pr < rows; pr++) {
            for (let pc = 0; pc < cols; pc++) {
              if (template.matrix[pr][pc] === 1) {
                board[r + pr][c + pc] = color;
                totalPlacedCells++;
              }
            }
          }
          break;
        }
      }
    }

    // Ensure no row or column is already 100% full before game starts!
    for (let r = 0; r < size; r++) {
      let rowFull = true;
      for (let c = 0; c < size; c++) {
        if (board[r][c] === null) {
          rowFull = false;
          break;
        }
      }
      if (rowFull) {
        board[r][Math.floor(Math.random() * size)] = null;
        totalPlacedCells--;
      }
    }
    for (let c = 0; c < size; c++) {
      let colFull = true;
      for (let r = 0; r < size; r++) {
        if (board[r][c] === null) {
          colFull = false;
          break;
        }
      }
      if (colFull) {
        board[Math.floor(Math.random() * size)][c] = null;
        totalPlacedCells--;
      }
    }

    // Must have a noticeable amount of blocks (e.g. 12 to 26 cells out of 64 on an 8x8 board)
    const minCells = Math.max(8, Math.round(size * size * 0.18));
    const maxCells = Math.min(size * size - 15, Math.round(size * size * 0.40));
    if (totalPlacedCells >= minCells && totalPlacedCells <= maxCells) {
      if (initialPieces && initialPieces.length > 0) {
        if (hasValidMoves(board, initialPieces, size)) {
          return board;
        }
      } else {
        return board;
      }
    }
  }

  // Safe fallback pattern with colorful clusters within 8x8 bounds (indices 0..size-1)
  const fallback = createEmptyBoard(size);
  fallback[1][1] = COLOR_PALETTE[0];
  fallback[1][2] = COLOR_PALETTE[0];
  fallback[2][1] = COLOR_PALETTE[0];
  fallback[2][2] = COLOR_PALETTE[0];
  if (size >= 6) {
    fallback[4][4] = COLOR_PALETTE[1];
    fallback[4][5] = COLOR_PALETTE[1];
    fallback[5][4] = COLOR_PALETTE[1];
    fallback[5][2] = COLOR_PALETTE[2];
    fallback[5][3] = COLOR_PALETTE[2];
    fallback[1][5] = COLOR_PALETTE[3];
    fallback[2][5] = COLOR_PALETTE[3];
  }
  if (size >= 8) {
    fallback[6][6] = COLOR_PALETTE[4];
    fallback[7][6] = COLOR_PALETTE[4];
  }
  return fallback;
}

/**
 * Counts cells in a matrix
 */
export function countPieceCells(matrix: number[][]): number {
  let count = 0;
  for (let r = 0; r < matrix.length; r++) {
    for (let c = 0; c < matrix[r].length; c++) {
      if (matrix[r][c] === 1) count++;
    }
  }
  return count;
}

/**
 * Generates N playable random pieces with diverse shapes and vibrant colors
 */
export function generateRandomPieces(count: number = 3): Piece[] {
  // Build weighted pool of templates
  const weightedPool: ShapeTemplate[] = [];
  for (const template of SHAPE_TEMPLATES) {
    const w = template.weight ?? 1;
    for (let i = 0; i < w; i++) {
      weightedPool.push(template);
    }
  }

  const pieces: Piece[] = [];
  for (let i = 0; i < count; i++) {
    const template = weightedPool[Math.floor(Math.random() * weightedPool.length)];
    const color = COLOR_PALETTE[Math.floor(Math.random() * COLOR_PALETTE.length)];
    pieces.push({
      id: `piece-${Date.now()}-${i}-${Math.random().toString(36).substring(2, 7)}`,
      name: template.name,
      matrix: template.matrix,
      color,
      cellCount: countPieceCells(template.matrix),
    });
  }
  return pieces;
}

/**
 * Checks if a shape can be placed at (startRow, startCol) on the board
 */
export function canPlacePiece(
  board: (ColorDef | null)[][],
  matrix: number[][],
  startRow: number,
  startCol: number,
  size: number = GRID_SIZE
): boolean {
  const rows = matrix.length;
  const cols = matrix[0].length;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (matrix[r][c] === 1) {
        const boardRow = startRow + r;
        const boardCol = startCol + c;

        // Check board boundary
        if (boardRow < 0 || boardRow >= size || boardCol < 0 || boardCol >= size) {
          return false;
        }

        // Check cell occupancy
        if (board[boardRow][boardCol] !== null) {
          return false;
        }
      }
    }
  }
  return true;
}

/**
 * Places a piece on the board and returns a new board state
 */
export function placePiece(
  board: (ColorDef | null)[][],
  piece: Piece,
  startRow: number,
  startCol: number
): (ColorDef | null)[][] {
  const newBoard = board.map(row => [...row]);
  const matrix = piece.matrix;

  for (let r = 0; r < matrix.length; r++) {
    for (let c = 0; c < matrix[r].length; c++) {
      if (matrix[r][c] === 1) {
        newBoard[startRow + r][startCol + c] = piece.color;
      }
    }
  }

  return newBoard;
}

export interface CompletedLines {
  rows: number[];
  cols: number[];
}

/**
 * Finds all fully filled rows and columns
 */
export function findCompletedLines(
  board: (ColorDef | null)[][],
  size: number = GRID_SIZE
): CompletedLines {
  const fullRows: number[] = [];
  const fullCols: number[] = [];

  // Check rows
  for (let r = 0; r < size; r++) {
    let isFull = true;
    for (let c = 0; c < size; c++) {
      if (board[r][c] === null) {
        isFull = false;
        break;
      }
    }
    if (isFull) {
      fullRows.push(r);
    }
  }

  // Check columns
  for (let c = 0; c < size; c++) {
    let isFull = true;
    for (let r = 0; r < size; r++) {
      if (board[r][c] === null) {
        isFull = false;
        break;
      }
    }
    if (isFull) {
      fullCols.push(c);
    }
  }

  return { rows: fullRows, cols: fullCols };
}

/**
 * Clears the specified rows and columns from the board, returning a new board
 */
export function clearCompletedLines(
  board: (ColorDef | null)[][],
  completed: CompletedLines,
  size: number = GRID_SIZE
): (ColorDef | null)[][] {
  const newBoard = board.map(row => [...row]);

  // Clear rows
  for (const r of completed.rows) {
    for (let c = 0; c < size; c++) {
      newBoard[r][c] = null;
    }
  }

  // Clear columns
  for (const c of completed.cols) {
    for (let r = 0; r < size; r++) {
      newBoard[r][c] = null;
    }
  }

  return newBoard;
}

/**
 * Checks if a specific piece can fit anywhere on the current board
 */
export function canPieceFitAnywhere(
  board: (ColorDef | null)[][],
  piece: Piece,
  size: number = GRID_SIZE
): boolean {
  const matrix = piece.matrix;
  const rows = matrix.length;
  const cols = matrix[0].length;

  for (let r = 0; r <= size - rows; r++) {
    for (let c = 0; c <= size - cols; c++) {
      if (canPlacePiece(board, matrix, r, c, size)) {
        return true;
      }
    }
  }
  return false;
}

/**
 * Checks if ANY of the available pieces can legally be placed anywhere on the board
 */
export function hasValidMoves(
  board: (ColorDef | null)[][],
  pieces: Piece[],
  size: number = GRID_SIZE
): boolean {
  if (pieces.length === 0) return true;
  for (const piece of pieces) {
    if (canPieceFitAnywhere(board, piece, size)) {
      return true;
    }
  }
  return false;
}

export interface ScoreResult {
  placementPoints: number;
  clearPoints: number;
  totalAwarded: number;
  totalLinesCleared: number;
  comboTier: string;
  comboMultiplier: number;
}

/**
 * Calculates score for a placement and subsequent line clears
 */
export function calculateMoveScore(
  cellsPlacedCount: number,
  linesClearedCount: number,
  streakCount: number // consecutive clears streak
): ScoreResult {
  const placementPoints = cellsPlacedCount; // 1 point per cell placed

  if (linesClearedCount === 0) {
    return {
      placementPoints,
      clearPoints: 0,
      totalAwarded: placementPoints,
      totalLinesCleared: 0,
      comboTier: '',
      comboMultiplier: 1,
    };
  }

  // Base points: 10 per line
  let baseLinePoints = linesClearedCount * 10;

  // Multi-line bonus
  let multiBonus = 0;
  let comboTier = 'NICE!';

  if (linesClearedCount === 2) {
    multiBonus = 15;
    comboTier = 'DOUBLE!';
  } else if (linesClearedCount === 3) {
    multiBonus = 35;
    comboTier = 'TRIPLE!';
  } else if (linesClearedCount === 4) {
    multiBonus = 65;
    comboTier = 'AMAZING!';
  } else if (linesClearedCount >= 5) {
    multiBonus = 100 + (linesClearedCount - 5) * 40;
    comboTier = 'LEGENDARY!';
  }

  // Consecutive turn streak multiplier: e.g. streak of 2 = 1.2x, streak of 3 = 1.4x...
  const streakMultiplier = 1 + Math.max(0, streakCount - 1) * 0.25;
  const clearPoints = Math.round((baseLinePoints + multiBonus) * streakMultiplier);

  return {
    placementPoints,
    clearPoints,
    totalAwarded: placementPoints + clearPoints,
    totalLinesCleared: linesClearedCount,
    comboTier,
    comboMultiplier: Number(streakMultiplier.toFixed(2)),
  };
}

// ----------------- COOL NEW FEATURES -----------------

export type GameMode = 'classic' | 'blitz';

export type ThemeId = 'cyberpunk' | 'candypop' | 'retro' | 'crystal';

export interface ThemeDef {
  id: ThemeId;
  name: string;
  bgGradient: string;
  boardBg: string;
  boardBorder: string;
  accentGlow: string;
}

export const THEMES: Record<ThemeId, ThemeDef> = {
  cyberpunk: {
    id: 'cyberpunk',
    name: 'Midnight Neon',
    bgGradient: 'bg-radial from-[#1e1b4b] via-[#0f0c29] to-[#08071a]',
    boardBg: 'from-[#13142e] to-[#0c0d20]',
    boardBorder: 'border-[#2b2d56]',
    accentGlow: 'rgba(168, 85, 247, 0.5)',
  },
  candypop: {
    id: 'candypop',
    name: 'Candy Pop',
    bgGradient: 'bg-radial from-[#3b0764] via-[#1e1035] to-[#0f0720]',
    boardBg: 'from-[#2e1045] to-[#1a0729]',
    boardBorder: 'border-[#ec4899]',
    accentGlow: 'rgba(236, 72, 153, 0.6)',
  },
  retro: {
    id: 'retro',
    name: 'Retro Arcade',
    bgGradient: 'bg-radial from-[#064e3b] via-[#022c22] to-[#01140e]',
    boardBg: 'from-[#063327] to-[#021f17]',
    boardBorder: 'border-[#10b981]',
    accentGlow: 'rgba(16, 185, 129, 0.6)',
  },
  crystal: {
    id: 'crystal',
    name: 'Crystal Prism',
    bgGradient: 'bg-radial from-[#0c4a6e] via-[#082f49] to-[#031525]',
    boardBg: 'from-[#07273d] to-[#031726]',
    boardBorder: 'border-[#38bdf8]',
    accentGlow: 'rgba(56, 189, 248, 0.6)',
  },
};

export interface PowerupsState {
  bombs: number;
  zaps: number;
  rerolls: number;
}

export const INITIAL_POWERUPS: PowerupsState = {
  bombs: 1,
  zaps: 1,
  rerolls: 2,
};

/**
 * 💣 Bomb Blast: Destroys up to a 3x3 area around center (row, col)
 */
export function executeBomb(
  board: (ColorDef | null)[][],
  centerRow: number,
  centerCol: number,
  size: number = GRID_SIZE
): {
  newBoard: (ColorDef | null)[][];
  clearedPositions: { row: number; col: number; color: ColorDef }[];
} {
  const newBoard = board.map(row => [...row]);
  const clearedPositions: { row: number; col: number; color: ColorDef }[] = [];

  for (let r = centerRow - 1; r <= centerRow + 1; r++) {
    for (let c = centerCol - 1; c <= centerCol + 1; c++) {
      if (r >= 0 && r < size && c >= 0 && c < size) {
        const cell = newBoard[r][c];
        if (cell !== null) {
          clearedPositions.push({ row: r, col: c, color: cell });
          newBoard[r][c] = null;
        }
      }
    }
  }

  return { newBoard, clearedPositions };
}

/**
 * ⚡ Laser Line Zap: Destroys an entire row or column
 */
export function executeLineZap(
  board: (ColorDef | null)[][],
  type: 'row' | 'col',
  index: number,
  size: number = GRID_SIZE
): {
  newBoard: (ColorDef | null)[][];
  clearedPositions: { row: number; col: number; color: ColorDef }[];
} {
  const newBoard = board.map(row => [...row]);
  const clearedPositions: { row: number; col: number; color: ColorDef }[] = [];

  if (type === 'row') {
    if (index >= 0 && index < size) {
      for (let c = 0; c < size; c++) {
        const cell = newBoard[index][c];
        if (cell !== null) {
          clearedPositions.push({ row: index, col: c, color: cell });
          newBoard[index][c] = null;
        }
      }
    }
  } else {
    if (index >= 0 && index < size) {
      for (let r = 0; r < size; r++) {
        const cell = newBoard[r][index];
        if (cell !== null) {
          clearedPositions.push({ row: r, col: index, color: cell });
          newBoard[r][index] = null;
        }
      }
    }
  }

  return { newBoard, clearedPositions };
}

/**
 * Fever / Blast Energy Meter calculation (0 to 100)
 */
export function calculateFeverCharge(
  currentCharge: number,
  cellsPlaced: number,
  linesCleared: number
): { nextCharge: number; shouldTriggerFever: boolean } {
  const chargeGain = cellsPlaced * 2 + linesCleared * 18 + (linesCleared >= 2 ? 15 : 0);
  const total = currentCharge + chargeGain;

  if (total >= 100) {
    return { nextCharge: 100, shouldTriggerFever: true };
  }
  return { nextCharge: total, shouldTriggerFever: false };
}

