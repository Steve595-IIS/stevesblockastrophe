/**
 * Web Audio API Procedural Sound & Synth Music System for Steve's Blockastrophe
 * Zero external audio files required, responsive, low latency, fully controllable
 */

class SoundSystem {
  private ctx: AudioContext | null = null;
  private isSoundEnabled: boolean = true;
  private isMusicEnabled: boolean = true;
  private bgmOscs: OscillatorNode[] = [];
  private bgmGain: GainNode | null = null;
  private bgmInterval: any = null;

  constructor() {
    // Read persisted settings
    try {
      const storedSound = localStorage.getItem('blockastrophe_sound') ?? localStorage.getItem('colorblast_sound');
      if (storedSound !== null) this.isSoundEnabled = storedSound === 'true';
      const storedMusic = localStorage.getItem('blockastrophe_music') ?? localStorage.getItem('colorblast_music');
      if (storedMusic !== null) this.isMusicEnabled = storedMusic === 'true';
    } catch {
      // Ignore localStorage issues
    }
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public getSoundEnabled(): boolean {
    return this.isSoundEnabled;
  }

  public getMusicEnabled(): boolean {
    return this.isMusicEnabled;
  }

  public setSoundEnabled(enabled: boolean) {
    this.isSoundEnabled = enabled;
    try {
      localStorage.setItem('blockastrophe_sound', String(enabled));
    } catch {}
  }

  public setMusicEnabled(enabled: boolean) {
    this.isMusicEnabled = enabled;
    try {
      localStorage.setItem('blockastrophe_music', String(enabled));
    } catch {}

    if (enabled) {
      this.startMusic();
    } else {
      this.stopMusic();
    }
  }

  /**
   * Sound when picking up or tapping a piece
   */
  public playPickup() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(380, now);
    osc.frequency.exponentialRampToValueAtTime(560, now + 0.08);

    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.1);
  }

  /**
   * Sound when snapping and dropping a piece onto the board
   */
  public playSnap() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    // Layer 1: Punchy pop
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(110, now + 0.12);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.13);

    // Layer 2: Click tick
    const click = this.ctx.createOscillator();
    const clickGain = this.ctx.createGain();
    click.type = 'sine';
    click.frequency.setValueAtTime(800, now);
    click.frequency.exponentialRampToValueAtTime(300, now + 0.04);
    clickGain.gain.setValueAtTime(0.12, now);
    clickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

    click.connect(clickGain);
    clickGain.connect(this.ctx.destination);

    click.start(now);
    click.stop(now + 0.05);
  }

  /**
   * Invalid placement thump / return
   */
  public playInvalid() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.15);

    gain.gain.setValueAtTime(0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.16);
  }

  /**
   * Line clear sound - single or multi-line harmonics
   */
  public playLineClear(linesCount: number, comboStreak: number) {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const baseFreq = 440 * Math.pow(1.05946, Math.min(12, (comboStreak - 1) * 2));

    // Musical arpeggio intervals: tonic, major 3rd, 5th, octave, 10th
    const notes = [1, 1.2599, 1.4983, 2.0, 2.5198];
    const notesToPlay = Math.min(5, linesCount + 2);

    for (let i = 0; i < notesToPlay; i++) {
      const startTime = now + i * 0.06;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(baseFreq * notes[i], startTime);

      const duration = 0.35 + i * 0.05;
      gain.gain.setValueAtTime(0.18, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + duration + 0.02);
    }

    // If multi-line (combo >= 2), add a sparkling shimmer
    if (linesCount >= 2) {
      setTimeout(() => {
        if (!this.ctx) return;
        const shimmerNow = this.ctx.currentTime;
        const chord = [baseFreq * 2, baseFreq * 2.5, baseFreq * 3];
        chord.forEach(freq => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, shimmerNow);
          gain.gain.setValueAtTime(0.08, shimmerNow);
          gain.gain.exponentialRampToValueAtTime(0.001, shimmerNow + 0.4);
          osc.connect(gain);
          gain.connect(this.ctx!.destination);
          osc.start(shimmerNow);
          osc.stop(shimmerNow + 0.45);
        });
      }, 150);
    }
  }

  /**
   * Game over sound
   */
  public playGameOver() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const notes = [392, 349.23, 329.63, 261.63]; // G4, F4, E4, C4

    notes.forEach((freq, idx) => {
      const startTime = now + idx * 0.18;
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.96, startTime + 0.3);

      gain.gain.setValueAtTime(0.15, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.35);

      osc.connect(gain);
      gain.connect(this.ctx!.destination);

      osc.start(startTime);
      osc.stop(startTime + 0.4);
    });
  }

  /**
   * 💣 Bomb explosion sound: bass boom + rumble
   */
  public playBomb() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(160, now);
    osc.frequency.exponentialRampToValueAtTime(35, now + 0.35);

    gain.gain.setValueAtTime(0.35, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.42);
  }

  /**
   * ⚡ Laser zap beam sound: sweep down
   */
  public playZap() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(900, now);
    osc.frequency.exponentialRampToValueAtTime(120, now + 0.22);

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.25);
  }

  /**
   * 🔄 Reroll shuffle sound: quick chromatic chime
   */
  public playReroll() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    [440, 554.37, 659.25, 880].forEach((freq, idx) => {
      const startTime = now + idx * 0.04;
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);

      gain.gain.setValueAtTime(0.1, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.15);

      osc.connect(gain);
      gain.connect(this.ctx!.destination);

      osc.start(startTime);
      osc.stop(startTime + 0.16);
    });
  }

  /**
   * 🔥 Fever mode trigger fanfare
   */
  public playFever() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    [523.25, 659.25, 783.99, 1046.5].forEach((freq, idx) => {
      const startTime = now + idx * 0.07;
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, startTime);

      gain.gain.setValueAtTime(0.2, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.35);

      osc.connect(gain);
      gain.connect(this.ctx!.destination);

      osc.start(startTime);
      osc.stop(startTime + 0.38);
    });
  }

  /**
   * 🌟 PERFECT CLEAR Fanfare & Celebration Sound
   * Multi-octave ascending arpeggio, shimmering chords, and triumphant fanfare
   */
  public playPerfectClear() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;

    // Phase 1: Rapid shimmering harp/chime arpeggio up across 2 octaves
    const arpeggioNotes = [261.63, 329.63, 392.0, 523.25, 659.25, 783.99, 1046.5, 1318.51, 1567.98, 2093.0];
    arpeggioNotes.forEach((freq, idx) => {
      const startTime = now + idx * 0.055;
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, startTime);

      gain.gain.setValueAtTime(0.15, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.45);

      osc.connect(gain);
      gain.connect(this.ctx!.destination);

      osc.start(startTime);
      osc.stop(startTime + 0.48);
    });

    // Phase 2: Triumphant Grand Major Chord (C major with high sparkle) at 0.6s
    const chordTime = now + 0.6;
    const majorChord = [523.25, 659.25, 783.99, 1046.5, 1567.98];
    majorChord.forEach((freq) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, chordTime);

      gain.gain.setValueAtTime(0.2, chordTime);
      gain.gain.exponentialRampToValueAtTime(0.001, chordTime + 1.8);

      osc.connect(gain);
      gain.connect(this.ctx!.destination);

      osc.start(chordTime);
      osc.stop(chordTime + 1.9);
    });

    // Phase 3: Shimmering bell overtone sparkle at 0.8s
    const bellTime = now + 0.85;
    [1046.5, 1318.5, 1567.98, 2093.0, 2637.0].forEach((freq, i) => {
      const t = bellTime + i * 0.08;
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.12, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.6);

      osc.connect(gain);
      gain.connect(this.ctx!.destination);

      osc.start(t);
      osc.stop(t + 0.65);
    });
  }

  /**
   * Game restart / start chime
   */
  public playStart() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const notes = [261.63, 329.63, 392.0, 523.25]; // C4, E4, G4, C5

    notes.forEach((freq, idx) => {
      const startTime = now + idx * 0.08;
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, startTime);

      gain.gain.setValueAtTime(0.12, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.25);

      osc.connect(gain);
      gain.connect(this.ctx!.destination);

      osc.start(startTime);
      osc.stop(startTime + 0.28);
    });
  }

  /**
   * Gentle, procedural ambient chill synth music loop
   */
  public startMusic() {
    if (!this.isMusicEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    if (this.bgmGain) return; // already playing

    this.bgmGain = this.ctx.createGain();
    this.bgmGain.gain.setValueAtTime(0.025, this.ctx.currentTime);
    this.bgmGain.connect(this.ctx.destination);

    // Chords in F Major pentatonic: F, A, C, D, G
    const chords = [
      [174.61, 220.0, 261.63], // F Maj
      [196.0, 246.94, 293.66], // G Maj
      [220.0, 261.63, 329.63], // A Min
      [146.83, 220.0, 293.66], // D Min
    ];

    let chordIdx = 0;

    const playChordStep = () => {
      if (!this.ctx || !this.bgmGain || !this.isMusicEnabled) return;
      const chord = chords[chordIdx % chords.length];
      chordIdx++;

      const stepTime = this.ctx.currentTime;
      chord.forEach(freq => {
        const osc = this.ctx!.createOscillator();
        const noteGain = this.ctx!.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, stepTime);

        // Smooth swell envelope
        noteGain.gain.setValueAtTime(0.001, stepTime);
        noteGain.gain.linearRampToValueAtTime(0.03, stepTime + 0.8);
        noteGain.gain.exponentialRampToValueAtTime(0.001, stepTime + 3.2);

        osc.connect(noteGain);
        noteGain.connect(this.bgmGain!);

        osc.start(stepTime);
        osc.stop(stepTime + 3.4);
      });
    };

    playChordStep();
    this.bgmInterval = setInterval(playChordStep, 3200);
  }

  public stopMusic() {
    if (this.bgmInterval) {
      clearInterval(this.bgmInterval);
      this.bgmInterval = null;
    }
    if (this.bgmGain && this.ctx) {
      try {
        this.bgmGain.gain.setValueAtTime(this.bgmGain.gain.value, this.ctx.currentTime);
        this.bgmGain.gain.linearRampToValueAtTime(0.0001, this.ctx.currentTime + 0.5);
      } catch {}
      this.bgmGain = null;
    }
  }
}

export const sound = new SoundSystem();
