import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createEmptyBoard,
  canPlacePiece,
  placePiece,
  findCompletedLines,
  clearCompletedLines,
  hasValidMoves,
  calculateMoveScore,
  COLOR_PALETTE,
  GRID_SIZE,
  Piece,
  executeBomb,
  executeLineZap,
  calculateFeverCharge,
  isBoardCompletelyEmpty,
  generatePreFilledBoard,
} from './logic.ts';

const testColor = COLOR_PALETTE[0];

const sample1x1: Piece = {
  id: 'test-1x1',
  name: '1x1 Dot',
  matrix: [[1]],
  color: testColor,
  cellCount: 1,
};

const sample2x2: Piece = {
  id: 'test-2x2',
  name: '2x2 Square',
  matrix: [
    [1, 1],
    [1, 1],
  ],
  color: testColor,
  cellCount: 4,
};

test('GRID_SIZE is 8', () => {
  assert.equal(GRID_SIZE, 8);
});

test('createEmptyBoard initializes 8x8 null grid by default', () => {
  const board = createEmptyBoard();
  assert.equal(board.length, 8);
  assert.equal(board[0].length, 8);
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      assert.equal(board[r][c], null);
    }
  }
});

test('isBoardCompletelyEmpty correctly identifies empty vs non-empty boards', () => {
  const empty = createEmptyBoard();
  assert.equal(isBoardCompletelyEmpty(empty), true);

  // Place a single block
  empty[4][5] = testColor;
  assert.equal(isBoardCompletelyEmpty(empty), false);

  empty[4][5] = null;
  assert.equal(isBoardCompletelyEmpty(empty), true);
});

test('generatePreFilledBoard generates 8x8 board with valid density and moves', () => {
  const pieces = [sample1x1, sample2x2];
  const board = generatePreFilledBoard(8, pieces);
  assert.equal(board.length, 8);
  assert.equal(board[0].length, 8);

  let filledCount = 0;
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      if (board[r][c] !== null) filledCount++;
    }
  }

  // Pre-filled density check for 8x8 (64 cells)
  assert.ok(filledCount >= 8 && filledCount <= 35, `Expected 8-35 blocks, got ${filledCount}`);
  // Solvability check
  assert.equal(hasValidMoves(board, pieces, 8), true);
});

test('canPlacePiece validates board bounds correctly for 8x8', () => {
  const board = createEmptyBoard();
  // Valid inside board
  assert.equal(canPlacePiece(board, sample2x2.matrix, 0, 0), true);
  assert.equal(canPlacePiece(board, sample2x2.matrix, 6, 6), true);
  // Out of bounds on bottom/right edge of 8x8
  assert.equal(canPlacePiece(board, sample2x2.matrix, 7, 6), false);
  assert.equal(canPlacePiece(board, sample2x2.matrix, 6, 7), false);
  // Negative indices
  assert.equal(canPlacePiece(board, sample2x2.matrix, -1, 0), false);
});

test('placePiece updates occupied cells and prevents overlap', () => {
  let board = createEmptyBoard();
  board = placePiece(board, sample2x2, 2, 3);

  // Check placed positions
  assert.equal(board[2][3], testColor);
  assert.equal(board[2][4], testColor);
  assert.equal(board[3][3], testColor);
  assert.equal(board[3][4], testColor);
  assert.equal(board[0][0], null);

  // Trying to place on top of occupied cells should fail
  assert.equal(canPlacePiece(board, sample1x1.matrix, 2, 3), false);
  // Placing in empty spot should succeed
  assert.equal(canPlacePiece(board, sample1x1.matrix, 0, 0), true);
});

test('findCompletedLines detects horizontal rows, vertical columns, and simultaneous intersections in 8x8', () => {
  let board = createEmptyBoard();

  // Fill row 3 completely (8 cells)
  for (let c = 0; c < 8; c++) {
    board[3][c] = testColor;
  }
  // Fill column 5 completely (8 cells)
  for (let r = 0; r < 8; r++) {
    board[r][5] = testColor;
  }

  const completed = findCompletedLines(board);
  assert.deepEqual(completed.rows, [3]);
  assert.deepEqual(completed.cols, [5]);

  // Now clear them
  const clearedBoard = clearCompletedLines(board, completed);
  // Check row 3 is now empty
  for (let c = 0; c < 8; c++) {
    assert.equal(clearedBoard[3][c], null);
  }
  // Check column 5 is now empty
  for (let r = 0; r < 8; r++) {
    assert.equal(clearedBoard[r][5], null);
  }
});

test('hasValidMoves returns false when no moves fit in 8x8', () => {
  // Completely fill 8x8 board except 1x1 at (0, 0)
  const board = createEmptyBoard();
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      if (r !== 0 || c !== 0) {
        board[r][c] = testColor;
      }
    }
  }

  // 1x1 should fit
  assert.equal(hasValidMoves(board, [sample1x1]), true);
  // 2x2 should NOT fit
  assert.equal(hasValidMoves(board, [sample2x2]), false);
});

test('calculateMoveScore awards proper points for placement, lines, and combos', () => {
  // 1 cell, 0 lines
  const res1 = calculateMoveScore(1, 0, 1);
  assert.equal(res1.totalAwarded, 1);
  assert.equal(res1.clearPoints, 0);

  // 4 cells, 1 line
  const res2 = calculateMoveScore(4, 1, 1);
  assert.equal(res2.placementPoints, 4);
  assert.equal(res2.clearPoints, 10);
  assert.equal(res2.totalAwarded, 14);

  // 4 cells, 2 lines (Double)
  const res3 = calculateMoveScore(4, 2, 1);
  assert.equal(res3.comboTier, 'DOUBLE!');
  assert.equal(res3.clearPoints, 35); // 20 + 15

  // 5 cells, 3 lines with streak = 2
  const res4 = calculateMoveScore(5, 3, 2);
  assert.equal(res4.comboTier, 'TRIPLE!');
  assert.ok(res4.clearPoints > (30 + 35));
});

test('executeBomb clears 3x3 surrounding cells in 8x8', () => {
  let board = createEmptyBoard();
  // Fill rows 2..4, cols 2..4
  for (let r = 2; r <= 4; r++) {
    for (let c = 2; c <= 4; c++) {
      board[r][c] = testColor;
    }
  }

  const { newBoard, clearedPositions } = executeBomb(board, 3, 3);
  assert.equal(clearedPositions.length, 9);
  // Ensure the center and surrounding cells are now null
  for (let r = 2; r <= 4; r++) {
    for (let c = 2; c <= 4; c++) {
      assert.equal(newBoard[r][c], null);
    }
  }
});

test('executeLineZap clears full row or column in 8x8', () => {
  let board = createEmptyBoard();
  for (let c = 0; c < 8; c++) {
    board[2][c] = testColor;
  }

  const { newBoard, clearedPositions } = executeLineZap(board, 'row', 2);
  assert.equal(clearedPositions.length, 8);
  for (let c = 0; c < 8; c++) {
    assert.equal(newBoard[2][c], null);
  }
});

test('calculateFeverCharge accumulates and triggers fever at 100', () => {
  const charge1 = calculateFeverCharge(0, 4, 0); // 8
  assert.equal(charge1.nextCharge, 8);
  assert.equal(charge1.shouldTriggerFever, false);

  const charge2 = calculateFeverCharge(80, 2, 2); // 80 + 4 + 36 + 15 = 135 -> 100 & true
  assert.equal(charge2.nextCharge, 100);
  assert.equal(charge2.shouldTriggerFever, true);
});
