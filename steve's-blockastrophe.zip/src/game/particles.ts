/**
 * Zero-GC Pooled Particle System for Color Blast Line Clears & Combos
 */

interface Particle {
  active: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  shape: 'circle' | 'square' | 'star';
  rotation: number;
  rotSpeed: number;
}

const POOL_CAPACITY = 300;

export class ParticleManager {
  private particles: Particle[] = [];
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private animId: number | null = null;
  private lastTime: number = 0;

  constructor() {
    for (let i = 0; i < POOL_CAPACITY; i++) {
      this.particles.push({
        active: false,
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        size: 0,
        color: '#ffffff',
        alpha: 1,
        life: 0,
        maxLife: 1,
        shape: 'circle',
        rotation: 0,
        rotSpeed: 0,
      });
    }
  }

  public attach(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.resize();
  }

  public resize() {
    if (!this.canvas) return;
    const rect = this.canvas.getBoundingClientRect();
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    this.canvas.width = rect.width * dpr;
    this.canvas.height = rect.height * dpr;
  }

  public detach() {
    if (this.animId !== null) {
      cancelAnimationFrame(this.animId);
      this.animId = null;
    }
    this.canvas = null;
    this.ctx = null;
  }

  public spawnBurst(x: number, y: number, color: string, count: number = 16, power: number = 1) {
    let spawned = 0;
    const shapes: ('circle' | 'square' | 'star')[] = ['circle', 'square', 'star'];

    for (let i = 0; i < POOL_CAPACITY && spawned < count; i++) {
      const p = this.particles[i];
      if (!p.active) {
        p.active = true;
        p.x = x;
        p.y = y;
        const angle = Math.random() * Math.PI * 2;
        const speed = (Math.random() * 220 + 80) * power;
        p.vx = Math.cos(angle) * speed;
        p.vy = Math.sin(angle) * speed;
        p.size = Math.random() * 8 + 4;
        p.color = color;
        p.alpha = 1;
        p.life = 0;
        p.maxLife = Math.random() * 0.4 + 0.35;
        p.shape = shapes[Math.floor(Math.random() * shapes.length)];
        p.rotation = Math.random() * Math.PI * 2;
        p.rotSpeed = (Math.random() - 0.5) * 8;
        spawned++;
      }
    }

    if (spawned > 0) {
      this.startLoop();
    }
  }

  private startLoop() {
    if (this.animId !== null) return;
    this.lastTime = performance.now();

    const loop = (now: number) => {
      const rawDt = (now - this.lastTime) / 1000;
      this.lastTime = now;
      const dt = Math.min(rawDt, 0.05);

      const stillActive = this.updateAndRender(dt);
      if (stillActive) {
        this.animId = requestAnimationFrame(loop);
      } else {
        this.animId = null;
        if (this.canvas && this.ctx) {
          this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        }
      }
    };

    this.animId = requestAnimationFrame(loop);
  }

  private updateAndRender(dt: number): boolean {
    if (!this.canvas || !this.ctx) return false;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const ctx = this.ctx;

    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    ctx.save();
    ctx.scale(dpr, dpr);

    let activeCount = 0;

    for (let i = 0; i < POOL_CAPACITY; i++) {
      const p = this.particles[i];
      if (!p.active) continue;

      activeCount++;
      p.life += dt;
      if (p.life >= p.maxLife) {
        p.active = false;
        continue;
      }

      // Physics
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 320 * dt; // gravity
      p.vx *= 0.96; // drag
      p.vy *= 0.96;
      p.rotation += p.rotSpeed * dt;

      const progress = p.life / p.maxLife;
      p.alpha = Math.max(0, 1 - progress);
      const currentSize = p.size * (1 - progress * 0.4);

      ctx.save();
      ctx.globalAlpha = p.alpha;
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rotation);
      ctx.fillStyle = p.color;

      if (p.shape === 'circle') {
        ctx.beginPath();
        ctx.arc(0, 0, currentSize, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.shape === 'square') {
        ctx.fillRect(-currentSize / 2, -currentSize / 2, currentSize, currentSize);
      } else if (p.shape === 'star') {
        this.drawStar(ctx, 0, 0, 4, currentSize, currentSize / 2);
      }

      ctx.restore();
    }

    ctx.restore();
    return activeCount > 0;
  }

  private drawStar(
    ctx: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    spikes: number,
    outerRadius: number,
    innerRadius: number
  ) {
    let rot = (Math.PI / 2) * 3;
    let x = cx;
    let y = cy;
    const step = Math.PI / spikes;

    ctx.beginPath();
    ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < spikes; i++) {
      x = cx + Math.cos(rot) * outerRadius;
      y = cy + Math.sin(rot) * outerRadius;
      ctx.lineTo(x, y);
      rot += step;

      x = cx + Math.cos(rot) * innerRadius;
      y = cy + Math.sin(rot) * innerRadius;
      ctx.lineTo(x, y);
      rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
    ctx.fill();
  }
}
