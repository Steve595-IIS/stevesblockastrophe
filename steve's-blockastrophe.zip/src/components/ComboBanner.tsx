import React from 'react';
import { Sparkles, Flame } from 'lucide-react';

interface ComboBannerProps {
  comboTier: string; // e.g. "DOUBLE!", "TRIPLE!", "AMAZING!", "LEGENDARY!"
  pointsAwarded: number;
  streakCount: number;
  visible: boolean;
}

export const ComboBanner: React.FC<ComboBannerProps> = ({
  comboTier,
  pointsAwarded,
  streakCount,
  visible,
}) => {
  if (!visible || !comboTier) return null;

  const isLegendary = comboTier === 'LEGENDARY!';
  const isAmazing = comboTier === 'AMAZING!';

  return (
    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-40 pointer-events-none flex flex-col items-center justify-center animate-pop-in">
      {/* Outer Glow */}
      <div className="relative flex flex-col items-center">
        {/* Combo Title */}
        <div
          className={`px-6 py-2 rounded-2xl font-display font-black tracking-widest text-2xl sm:text-3xl uppercase shadow-[0_10px_35px_rgba(0,0,0,0.8)] border flex items-center gap-2 ${
            isLegendary
              ? 'bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 text-white border-amber-300 drop-shadow-[0_0_20px_rgba(245,158,11,0.8)]'
              : isAmazing
              ? 'bg-gradient-to-r from-purple-600 via-pink-500 to-cyan-400 text-white border-pink-300 drop-shadow-[0_0_15px_rgba(236,72,153,0.8)]'
              : 'bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 text-slate-950 border-cyan-200 drop-shadow-[0_0_15px_rgba(6,182,212,0.8)]'
          }`}
        >
          {streakCount > 1 ? (
            <Flame className="w-6 h-6 fill-amber-300 text-amber-300 animate-bounce" />
          ) : (
            <Sparkles className="w-6 h-6 fill-yellow-300 text-yellow-300" />
          )}
          <span>{comboTier}</span>
        </div>

        {/* Points Pill */}
        <div className="mt-1.5 px-3 py-0.5 rounded-full bg-slate-950/90 border border-white/20 text-xs sm:text-sm font-black text-amber-300 tabular-nums shadow-lg">
          +{pointsAwarded} PTS
        </div>
      </div>
    </div>
  );
};
