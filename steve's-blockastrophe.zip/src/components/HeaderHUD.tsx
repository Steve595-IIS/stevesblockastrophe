import React from 'react';
import { Volume2, VolumeX, Music, RotateCcw, Pause, HelpCircle, Trophy, Flame, Timer, Palette } from 'lucide-react';
import { GameMode, ThemeDef } from '../game/logic.ts';

interface HeaderHUDProps {
  score: number;
  bestScore: number;
  linesCleared: number;
  comboStreak: number;
  gameMode: GameMode;
  blitzTimeLeft: number;
  theme: ThemeDef;
  isMuted: boolean;
  isMusicEnabled: boolean;
  onToggleMute: () => void;
  onToggleMusic: () => void;
  onCycleTheme: () => void;
  onPause: () => void;
  onRestart: () => void;
  onOpenSettings: () => void;
}

export const HeaderHUD: React.FC<HeaderHUDProps> = ({
  score,
  bestScore,
  linesCleared,
  comboStreak,
  gameMode,
  blitzTimeLeft,
  theme,
  isMuted,
  isMusicEnabled,
  onToggleMute,
  onToggleMusic,
  onCycleTheme,
  onPause,
  onRestart,
  onOpenSettings,
}) => {
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <header className="w-full max-w-md mx-auto pt-1 sm:pt-2 pb-1 px-2.5 flex flex-col gap-1.5 z-10 select-none">
      {/* 1. Centered Title & Brand Lockup */}
      <div className="flex flex-col items-center justify-center text-center w-full">
        <div className="flex items-center justify-center gap-1.5 sm:gap-2 flex-wrap">
          <h1 className="font-display font-black text-xs sm:text-base tracking-wider bg-gradient-to-r from-cyan-400 via-pink-500 to-amber-400 bg-clip-text text-transparent drop-shadow-[0_2px_12px_rgba(236,72,153,0.35)]">
            STEVE&apos;S BLOCKASTROPHE
          </h1>

          {/* Mode badge */}
          <span className={`px-1.5 sm:px-2 py-0.5 rounded-full text-[8px] sm:text-[9px] font-black uppercase tracking-wider ${
            gameMode === 'blitz'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40'
              : 'bg-purple-500/20 text-purple-300 border border-purple-400/40'
          }`}>
            {gameMode === 'blitz' ? '⚡ BLITZ' : 'CLASSIC'}
          </span>

          {comboStreak > 1 && (
            <span className="flex items-center gap-0.5 px-1.5 sm:px-2 py-0.5 rounded-full bg-gradient-to-r from-orange-500 to-pink-500 text-[9px] sm:text-[10px] font-black uppercase text-white tracking-wide shadow-[0_0_12px_rgba(255,100,0,0.6)] animate-bounce">
              <Flame className="w-2.5 h-2.5 sm:w-3 sm:h-3 fill-yellow-300 text-yellow-300" />
              {comboStreak}x
            </span>
          )}
        </div>

        <p className="text-[9px] sm:text-[11px] text-slate-400 font-medium tracking-wide mt-0.5">
          Survive Steve&apos;s 8x8 Grid · Place smart. Clear everything.
        </p>
      </div>

      {/* 2. Centered Quick Toolbar */}
      <div className="flex items-center justify-center gap-1 sm:gap-1.5 w-full">
        {/* Theme Switcher Button */}
        <button
          type="button"
          onClick={onCycleTheme}
          title={`Current Theme: ${theme.name}. Click to switch theme.`}
          aria-label="Switch Theme"
          className="p-1.5 sm:p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 active:scale-95 touch-manipulation border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer"
        >
          <Palette className="w-3.5 h-3.5 text-pink-400" />
        </button>

        {/* Sound Toggle Button */}
        <button
          type="button"
          onClick={onToggleMute}
          title={isMuted ? 'Unmute Sound (M)' : 'Mute Sound (M)'}
          aria-label={isMuted ? 'Unmute Sound' : 'Mute Sound'}
          className="p-1.5 sm:p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 active:scale-95 touch-manipulation border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer"
        >
          {isMuted ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5 text-emerald-400" />}
        </button>

        {/* Music Toggle */}
        <button
          type="button"
          onClick={onToggleMusic}
          title={isMusicEnabled ? 'Turn Off Music' : 'Turn On Music'}
          aria-label={isMusicEnabled ? 'Turn Off Music' : 'Turn On Music'}
          className={`p-1.5 sm:p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 active:scale-95 touch-manipulation border border-white/10 transition-all cursor-pointer ${
            isMusicEnabled ? 'text-purple-400' : 'text-slate-500'
          }`}
        >
          <Music className="w-3.5 h-3.5" />
        </button>

        {/* Pause Button */}
        <button
          type="button"
          onClick={onPause}
          title="Pause Game (Esc or P)"
          aria-label="Pause Game"
          className="p-1.5 sm:p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 active:scale-95 touch-manipulation border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer"
        >
          <Pause className="w-3.5 h-3.5 text-amber-400" />
        </button>

        {/* Restart Button */}
        <button
          type="button"
          onClick={onRestart}
          title="Restart Game (R)"
          aria-label="Restart Game"
          className="p-1.5 sm:p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 active:scale-95 touch-manipulation border border-white/10 text-slate-300 hover:text-rose-400 transition-all cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
        </button>

        {/* Settings & Help Button */}
        <button
          type="button"
          onClick={onOpenSettings}
          title="Settings & How to Play"
          aria-label="Settings and How to Play"
          className="p-1.5 sm:p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 active:scale-95 touch-manipulation border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer"
        >
          <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
        </button>
      </div>

      {/* Score and Stats Panel */}
      <div className={`grid ${gameMode === 'blitz' ? 'grid-cols-4' : 'grid-cols-3'} gap-2 w-full`}>
        {/* Blitz Mode Timer Card */}
        {gameMode === 'blitz' && (
          <div className={`flex flex-col items-center justify-center p-2 rounded-xl bg-gradient-to-b from-slate-900/90 to-[#12132b] border ${
            blitzTimeLeft <= 10
              ? 'border-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.6)] animate-pulse'
              : 'border-orange-500/40 shadow-[0_4px_12px_rgba(0,0,0,0.4)]'
          }`}>
            <div className="flex items-center gap-1">
              <Timer className={`w-3 h-3 ${blitzTimeLeft <= 10 ? 'text-rose-400' : 'text-orange-400'}`} />
              <span className={`text-[10px] font-bold tracking-wider uppercase ${
                blitzTimeLeft <= 10 ? 'text-rose-400' : 'text-orange-400'
              }`}>
                TIME
              </span>
            </div>
            <span className={`font-display font-black text-xl sm:text-2xl tabular-nums tracking-wide ${
              blitzTimeLeft <= 10 ? 'text-rose-400' : 'text-white'
            }`}>
              {formatTime(blitzTimeLeft)}
            </span>
          </div>
        )}

        {/* Score Card */}
        <div className="flex flex-col items-center justify-center p-2 rounded-xl bg-gradient-to-b from-slate-900/90 to-[#12132b] border border-cyan-500/30 shadow-[0_4px_12px_rgba(0,0,0,0.4)]">
          <span className="text-[10px] font-bold tracking-wider text-cyan-400 uppercase">
            SCORE
          </span>
          <span
            data-testid="score-value"
            className="font-display font-black text-xl sm:text-2xl tabular-nums text-white tracking-wide"
          >
            {score}
          </span>
        </div>

        {/* Best Score Card */}
        <div className="flex flex-col items-center justify-center p-2 rounded-xl bg-gradient-to-b from-slate-900/90 to-[#12132b] border border-amber-500/30 shadow-[0_4px_12px_rgba(0,0,0,0.4)]">
          <div className="flex items-center gap-1">
            <Trophy className="w-3 h-3 text-amber-400" />
            <span className="text-[10px] font-bold tracking-wider text-amber-400 uppercase">
              BEST
            </span>
          </div>
          <span
            data-testid="best-value"
            className="font-display font-black text-xl sm:text-2xl tabular-nums text-amber-300 tracking-wide"
          >
            {bestScore}
          </span>
        </div>

        {/* Lines Cleared Card */}
        <div className="flex flex-col items-center justify-center p-2 rounded-xl bg-gradient-to-b from-slate-900/90 to-[#12132b] border border-purple-500/30 shadow-[0_4px_12px_rgba(0,0,0,0.4)]">
          <span className="text-[10px] font-bold tracking-wider text-purple-400 uppercase">
            LINES
          </span>
          <span
            data-testid="lines-value"
            className="font-display font-black text-xl sm:text-2xl tabular-nums text-purple-300 tracking-wide"
          >
            {linesCleared}
          </span>
        </div>
      </div>
    </header>
  );
};
