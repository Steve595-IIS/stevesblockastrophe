import React, { useEffect } from 'react';
import { Play, Sparkles, Volume2, VolumeX, HelpCircle, Trophy, Zap, Flame } from 'lucide-react';
import { sound } from '../game/audio.ts';
import { GameMode } from '../game/logic.ts';

interface TitleScreenProps {
  onStart: (mode: GameMode) => void;
  bestScore: number;
  selectedMode: GameMode;
  onSelectMode: (mode: GameMode) => void;
  onOpenHowToPlay: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStart,
  bestScore,
  selectedMode,
  onSelectMode,
  onOpenHowToPlay,
  isMuted,
  onToggleMute,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        onStart(selectedMode);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onStart, selectedMode]);

  return (
    <div className="relative flex flex-col items-center justify-between h-[100dvh] max-h-screen w-full px-4 pt-[max(0.75rem,env(safe-area-inset-top))] pb-[max(0.75rem,env(safe-area-inset-bottom))] bg-[#0b0c1b] bg-radial from-[#1e1b4b] via-[#0f0c29] to-[#08071a] overflow-hidden text-white select-none">
      {/* Background ambient decorative glowing orbs */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-20 w-80 h-80 rounded-full bg-pink-500/10 blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-purple-600/15 blur-[100px] pointer-events-none" />

      {/* Top utility row */}
      <header className="w-full max-w-md flex items-center justify-between z-10 shrink-0">
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-semibold text-amber-300">
          <Trophy className="w-4 h-4 text-amber-400" />
          <span>BEST: <strong className="font-bold tabular-nums text-white">{bestScore}</strong></span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onToggleMute}
            aria-label={isMuted ? 'Unmute audio' : 'Mute audio'}
            className="p-2 sm:p-2.5 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer"
          >
            {isMuted ? <VolumeX className="w-4 h-4 sm:w-5 sm:h-5 text-rose-400" /> : <Volume2 className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-400" />}
          </button>
          <button
            type="button"
            onClick={onOpenHowToPlay}
            aria-label="How to play instructions"
            className="p-2 sm:p-2.5 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer"
          >
            <HelpCircle className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-400" />
          </button>
        </div>
      </header>

      {/* Centerpiece Hero Section */}
      <main className="flex flex-col items-center justify-center my-auto z-10 max-w-md w-full text-center py-1">
        {/* Perfectly Centered Title Lockup */}
        <div className="relative mb-3 flex flex-col items-center justify-center text-center w-full">
          {/* Floating glowing background decorative block gems */}
          <div className="absolute -top-1 left-3 sm:left-8 w-4 h-4 rounded-md bg-cyan-400 rotate-12 shadow-[0_0_12px_rgba(6,182,212,0.8)] opacity-90 animate-float pointer-events-none" />
          <div className="absolute -top-1 right-3 sm:right-8 w-5 h-5 rounded-md bg-pink-500 -rotate-12 shadow-[0_0_15px_rgba(236,72,153,0.8)] opacity-90 animate-float pointer-events-none" style={{ animationDelay: '1.2s' }} />
          <div className="absolute bottom-6 left-2 sm:left-6 w-4 h-4 rounded-md bg-emerald-400 -rotate-15 shadow-[0_0_12px_rgba(52,211,153,0.8)] opacity-85 animate-float pointer-events-none" style={{ animationDelay: '0.6s' }} />
          <div className="absolute bottom-6 right-2 sm:right-6 w-4 h-4 rounded-md bg-amber-400 rotate-15 shadow-[0_0_12px_rgba(251,191,36,0.8)] opacity-85 animate-float pointer-events-none" style={{ animationDelay: '1.8s' }} />

          <h1 className="flex flex-col items-center justify-center text-center">
            <span className="font-display font-black text-2xl sm:text-3xl tracking-widest bg-gradient-to-r from-cyan-300 via-sky-400 to-purple-400 bg-clip-text text-transparent drop-shadow-[0_0_20px_rgba(56,189,248,0.5)]">
              STEVE&apos;S
            </span>
            <span className="font-display font-black text-3xl sm:text-5xl tracking-wide bg-gradient-to-r from-rose-500 via-orange-400 to-amber-300 bg-clip-text text-transparent drop-shadow-[0_0_30px_rgba(244,63,94,0.6)] uppercase mt-0.5">
              BLOCKASTROPHE
            </span>
          </h1>

          {/* Subtitle kicker */}
          <p className="mt-1.5 text-xs sm:text-sm font-semibold text-slate-300 tracking-wide text-center">
            Survive the 8x8 Block Grid · Place smart. Clear everything.
          </p>
        </div>

        {/* Hero Interactive Block Centerpiece Preview */}
        <div className="relative p-2 sm:p-2.5 mb-3 sm:mb-4 bg-slate-900/60 border border-white/10 rounded-2xl shadow-[0_15px_35px_rgba(0,0,0,0.5)]">
          <div className="grid grid-cols-4 gap-1.5 w-32 h-32 sm:w-36 sm:h-36 mx-auto p-1.5 bg-[#080718] rounded-xl border border-white/5 grid-slot">
            <div className="rounded-lg bg-gradient-to-br from-cyan-400 to-blue-600 block-tile animate-pop-in" />
            <div className="rounded-lg bg-gradient-to-br from-cyan-400 to-blue-600 block-tile animate-pop-in" />
            <div className="rounded-lg bg-gradient-to-br from-purple-400 to-indigo-600 block-tile animate-pop-in" />
            <div className="rounded-lg bg-gradient-to-br from-purple-400 to-indigo-600 block-tile animate-pop-in" />

            <div className="rounded-lg bg-gradient-to-br from-pink-400 to-rose-600 block-tile animate-pop-in" />
            <div className="rounded-lg bg-slate-800/20 border border-white/5" />
            <div className="rounded-lg bg-slate-800/20 border border-white/5" />
            <div className="rounded-lg bg-gradient-to-br from-amber-400 to-orange-600 block-tile animate-pop-in" />

            <div className="rounded-lg bg-gradient-to-br from-pink-400 to-rose-600 block-tile animate-pop-in" />
            <div className="rounded-lg bg-slate-800/20 border border-white/5" />
            <div className="rounded-lg bg-slate-800/20 border border-white/5" />
            <div className="rounded-lg bg-gradient-to-br from-amber-400 to-orange-600 block-tile animate-pop-in" />

            <div className="rounded-lg bg-gradient-to-br from-emerald-300 to-teal-500 block-tile animate-pop-in" />
            <div className="rounded-lg bg-gradient-to-br from-lime-300 to-green-600 block-tile animate-pop-in" />
            <div className="rounded-lg bg-gradient-to-br from-yellow-300 to-amber-500 block-tile animate-pop-in" />
            <div className="rounded-lg bg-gradient-to-br from-rose-400 to-red-600 block-tile animate-pop-in" />
          </div>

          <div className="flex items-center justify-center gap-1.5 mt-1.5 text-[11px] sm:text-xs font-semibold text-cyan-300">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
            <span>8x8 Pre-filled Board · Perfect Clear +10,000</span>
          </div>
        </div>

        {/* Mode Selector Tabs */}
        <div className="flex items-center gap-2 p-1 rounded-2xl bg-slate-900/80 border border-white/10 mb-3 sm:mb-4 w-full max-w-xs">
          <button
            type="button"
            onClick={() => onSelectMode('classic')}
            className={`flex-1 py-1.5 sm:py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              selectedMode === 'classic'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-[0_0_12px_rgba(147,51,234,0.5)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            <span>Classic</span>
          </button>
          <button
            type="button"
            onClick={() => onSelectMode('blitz')}
            className={`flex-1 py-1.5 sm:py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              selectedMode === 'blitz'
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black shadow-[0_0_12px_rgba(245,158,11,0.5)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-amber-300" />
            <span>Blitz 60s</span>
          </button>
        </div>

        {/* Primary Start CTA Button */}
        <button
          type="button"
          data-start="true"
          onClick={() => {
            sound.playStart();
            onStart(selectedMode);
          }}
          className="group relative flex items-center justify-center gap-3 w-full max-w-xs py-3 sm:py-3.5 px-6 sm:px-8 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-500 text-slate-950 font-display font-black text-lg sm:text-xl tracking-wide shadow-[0_10px_30px_rgba(20,184,166,0.5)] hover:shadow-[0_15px_40px_rgba(20,184,166,0.7)] hover:scale-105 active:scale-95 transition-all cursor-pointer"
        >
          <Play className="w-5 h-5 sm:w-6 sm:h-6 fill-slate-950" />
          <span>START {selectedMode === 'blitz' ? 'BLITZ' : 'GAME'}</span>
          <span className="absolute -top-1 -right-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-300 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-400"></span>
          </span>
        </button>

        <p className="hidden sm:block mt-2 text-xs text-slate-400 font-medium">
          Press <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-slate-200">Enter</kbd> or <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-slate-200">Space</kbd> to start
        </p>
      </main>

      {/* Flat borderless control hints */}
      <footer className="w-full text-center text-[10px] sm:text-xs text-slate-500 py-1 z-10 shrink-0">
        Drag or Click blocks onto 8x8 board · Pre-filled Board · +10,000 Perfect Clear · M Mute · R Restart
      </footer>
    </div>
  );
};
