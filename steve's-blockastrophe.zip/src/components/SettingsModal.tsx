import React from 'react';
import { X, Volume2, VolumeX, Music, RotateCcw, Keyboard, HelpCircle } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  isMuted: boolean;
  isMusicEnabled: boolean;
  onToggleMute: () => void;
  onToggleMusic: () => void;
  onRestart: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  isMuted,
  isMusicEnabled,
  onToggleMute,
  onToggleMusic,
  onRestart,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-pop-in">
      <div className="relative w-full max-w-sm max-h-[92dvh] overflow-y-auto p-5 sm:p-6 rounded-3xl bg-[#141530] border border-white/10 shadow-2xl text-white">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-cyan-400" />
            <h2 className="font-display font-black text-xl text-white">How to Play & Settings</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Audio Toggles */}
        <div className="flex flex-col gap-2.5 my-4">
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-white/5">
            <div className="flex items-center gap-2.5">
              {isMuted ? <VolumeX className="w-5 h-5 text-rose-400" /> : <Volume2 className="w-5 h-5 text-emerald-400" />}
              <div className="flex flex-col">
                <span className="text-sm font-semibold">Sound Effects</span>
                <span className="text-[10px] text-slate-400">Pops, snaps, and line clears</span>
              </div>
            </div>
            <button
              type="button"
              onClick={onToggleMute}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                !isMuted ? 'bg-emerald-500 text-slate-950' : 'bg-slate-700 text-slate-300'
              }`}
            >
              {!isMuted ? 'ON' : 'OFF'}
            </button>
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-white/5">
            <div className="flex items-center gap-2.5">
              <Music className={`w-5 h-5 ${isMusicEnabled ? 'text-purple-400' : 'text-slate-500'}`} />
              <div className="flex flex-col">
                <span className="text-sm font-semibold">Ambient Music</span>
                <span className="text-[10px] text-slate-400">Soft synth pad chords</span>
              </div>
            </div>
            <button
              type="button"
              onClick={onToggleMusic}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                isMusicEnabled ? 'bg-purple-500 text-slate-950' : 'bg-slate-700 text-slate-300'
              }`}
            >
              {isMusicEnabled ? 'ON' : 'OFF'}
            </button>
          </div>
        </div>

        {/* Rules Guide */}
        <div className="p-3 rounded-xl bg-slate-900/40 border border-white/5 text-xs text-slate-300 space-y-1.5 my-3">
          <p className="font-bold text-cyan-300">Rules & Strategy:</p>
          <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-300">
            <li>Drag or tap shapes onto the <strong>8x8 board</strong> to place them.</li>
            <li>Board starts <strong>pre-filled</strong> with colorful solvable patterns.</li>
            <li>Fill an entire <strong>row or column</strong> to clear lines and score.</li>
            <li>Wipe every block off the board for a <strong>+10,000 PERFECT CLEAR</strong>!</li>
            <li>Use 💣 Bomb, ⚡ Zap, and 🔄 Reroll boosters in tight spots.</li>
            <li>Game ends when none of the 3 current shapes can fit.</li>
          </ul>
        </div>

        {/* Keyboard Shortcuts */}
        <div className="p-3 rounded-xl bg-slate-900/30 border border-white/5 text-xs text-slate-400 mb-4">
          <div className="flex items-center gap-1.5 font-bold text-slate-300 mb-1.5">
            <Keyboard className="w-3.5 h-3.5 text-amber-400" />
            <span>Keyboard Shortcuts</span>
          </div>
          <div className="grid grid-cols-2 gap-1 text-[11px]">
            <div><kbd className="px-1 py-0.5 rounded bg-white/10 text-slate-200">R</kbd> Restart</div>
            <div><kbd className="px-1 py-0.5 rounded bg-white/10 text-slate-200">M</kbd> Toggle Sound</div>
            <div><kbd className="px-1 py-0.5 rounded bg-white/10 text-slate-200">Esc / P</kbd> Pause</div>
            <div><kbd className="px-1 py-0.5 rounded bg-white/10 text-slate-200">Enter</kbd> Start / Restart</div>
          </div>
        </div>

        {/* Restart Button */}
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => {
              if (window.confirm('Restart game with a clean board?')) {
                onRestart();
                onClose();
              }
            }}
            className="flex-1 py-2.5 px-4 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/40 text-rose-300 text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Restart Game</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-all cursor-pointer"
          >
            Resume Playing
          </button>
        </div>
      </div>
    </div>
  );
};
