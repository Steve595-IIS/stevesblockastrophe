import React, { useEffect } from 'react';
import { RotateCcw, Trophy, Sparkles, Layers, Award } from 'lucide-react';
import { sound } from '../game/audio.ts';

interface GameOverModalProps {
  score: number;
  bestScore: number;
  linesCleared: number;
  isNewBest: boolean;
  onRestart: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  bestScore,
  linesCleared,
  isNewBest,
  onRestart,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        onRestart();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onRestart]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-pop-in">
      <div className="relative w-full max-w-sm max-h-[92dvh] overflow-y-auto p-5 sm:p-6 rounded-3xl bg-gradient-to-b from-[#18193a] to-[#0e0f24] border-2 border-purple-500/40 shadow-[0_20px_60px_rgba(0,0,0,0.8)] text-center flex flex-col items-center">
        {/* Glow pill */}
        <div className="absolute -top-5 px-4 py-1.5 rounded-full bg-gradient-to-r from-rose-500 to-pink-500 text-xs font-black uppercase tracking-widest text-white shadow-[0_0_20px_rgba(244,63,94,0.6)] flex items-center gap-1.5">
          <Award className="w-4 h-4" />
          <span>NO MORE MOVES!</span>
        </div>

        <h2 className="mt-2 font-display font-black text-3xl tracking-wide text-white">
          GAME OVER
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Great effort! Here is how you scored:
        </p>

        {/* New Best badge */}
        {isNewBest && (
          <div className="mt-3 flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400/50 text-amber-300 text-xs font-black uppercase tracking-wider animate-bounce">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>NEW ALL-TIME RECORD!</span>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 w-full my-5">
          {/* Final Score */}
          <div className="col-span-2 p-3 rounded-2xl bg-gradient-to-r from-purple-900/40 to-indigo-900/40 border border-purple-400/30 flex flex-col items-center">
            <span className="text-[11px] font-bold uppercase tracking-wider text-purple-300">
              FINAL SCORE
            </span>
            <span className="font-display font-black text-4xl tabular-nums text-white mt-0.5">
              {score}
            </span>
          </div>

          {/* Best Record */}
          <div className="p-3 rounded-2xl bg-slate-900/60 border border-white/10 flex flex-col items-center">
            <div className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-amber-400">
              <Trophy className="w-3.5 h-3.5" />
              <span>BEST</span>
            </div>
            <span className="font-display font-black text-2xl tabular-nums text-amber-300 mt-0.5">
              {bestScore}
            </span>
          </div>

          {/* Lines Cleared */}
          <div className="p-3 rounded-2xl bg-slate-900/60 border border-white/10 flex flex-col items-center">
            <div className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-cyan-400">
              <Layers className="w-3.5 h-3.5" />
              <span>LINES</span>
            </div>
            <span className="font-display font-black text-2xl tabular-nums text-cyan-300 mt-0.5">
              {linesCleared}
            </span>
          </div>
        </div>

        {/* Restart CTA Button */}
        <button
          type="button"
          data-start="true"
          onClick={() => {
            sound.playStart();
            onRestart();
          }}
          className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 active:scale-95 text-slate-950 font-display font-black text-lg tracking-wide shadow-[0_10px_25px_rgba(20,184,166,0.4)] flex items-center justify-center gap-2 cursor-pointer transition-all"
        >
          <RotateCcw className="w-5 h-5 fill-slate-950" />
          <span>PLAY AGAIN</span>
        </button>

        <p className="mt-2 text-xs text-slate-500">
          Or press <kbd className="px-1 py-0.5 rounded bg-white/10 text-slate-300">Enter</kbd>
        </p>
      </div>
    </div>
  );
};
