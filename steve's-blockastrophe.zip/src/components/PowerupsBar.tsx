import React from 'react';
import { Bomb, Zap, RefreshCw, X } from 'lucide-react';
import { PowerupsState } from '../game/logic.ts';

export type ActiveTool = 'none' | 'bomb' | 'zap';

interface PowerupsBarProps {
  powerups: PowerupsState;
  activeTool: ActiveTool;
  onSelectTool: (tool: ActiveTool) => void;
  onReroll: () => void;
  disabled?: boolean;
}

export const PowerupsBar: React.FC<PowerupsBarProps> = ({
  powerups,
  activeTool,
  onSelectTool,
  onReroll,
  disabled = false,
}) => {
  return (
    <div className="w-full max-w-md mx-auto px-2 py-1 flex items-center justify-between gap-2 z-10 select-none">
      {/* Bomb Booster */}
      <button
        type="button"
        disabled={disabled || powerups.bombs <= 0}
        onClick={() => onSelectTool(activeTool === 'bomb' ? 'none' : 'bomb')}
        className={`relative flex-1 py-1.5 sm:py-2 px-2 sm:px-2.5 rounded-xl border flex items-center justify-center gap-1 sm:gap-1.5 transition-all cursor-pointer touch-manipulation active:scale-95 ${
          activeTool === 'bomb'
            ? 'bg-rose-600/30 border-rose-400 text-rose-300 ring-2 ring-rose-500/50 shadow-[0_0_15px_rgba(244,63,94,0.5)] animate-pulse'
            : powerups.bombs > 0
            ? 'bg-slate-900/80 hover:bg-slate-800/90 border-rose-500/30 text-rose-300'
            : 'bg-slate-900/40 border-white/5 text-slate-600 cursor-not-allowed opacity-50'
        }`}
        title="Bomb: Destroys a 3x3 block area"
        aria-label={`Bomb booster, ${powerups.bombs} remaining`}
      >
        <Bomb className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-rose-400" />
        <span className="text-[11px] sm:text-xs font-bold">Bomb</span>
        <span className="ml-auto px-1.5 py-0.2 rounded-full bg-rose-500/20 text-[10px] font-black tabular-nums border border-rose-500/30">
          {powerups.bombs}
        </span>
        {activeTool === 'bomb' && (
          <span className="absolute -top-1.5 -right-1 px-1 rounded-full bg-rose-500 text-[8px] font-black text-white">
            ACTIVE
          </span>
        )}
      </button>

      {/* Laser Line Zap */}
      <button
        type="button"
        disabled={disabled || powerups.zaps <= 0}
        onClick={() => onSelectTool(activeTool === 'zap' ? 'none' : 'zap')}
        className={`relative flex-1 py-1.5 sm:py-2 px-2 sm:px-2.5 rounded-xl border flex items-center justify-center gap-1 sm:gap-1.5 transition-all cursor-pointer touch-manipulation active:scale-95 ${
          activeTool === 'zap'
            ? 'bg-cyan-600/30 border-cyan-400 text-cyan-300 ring-2 ring-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.5)] animate-pulse'
            : powerups.zaps > 0
            ? 'bg-slate-900/80 hover:bg-slate-800/90 border-cyan-500/30 text-cyan-300'
            : 'bg-slate-900/40 border-white/5 text-slate-600 cursor-not-allowed opacity-50'
        }`}
        title="Laser Zap: Clears an entire row or column"
        aria-label={`Laser Zap booster, ${powerups.zaps} remaining`}
      >
        <Zap className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-cyan-400" />
        <span className="text-[11px] sm:text-xs font-bold">Zap</span>
        <span className="ml-auto px-1.5 py-0.2 rounded-full bg-cyan-500/20 text-[10px] font-black tabular-nums border border-cyan-500/30">
          {powerups.zaps}
        </span>
        {activeTool === 'zap' && (
          <span className="absolute -top-1.5 -right-1 px-1 rounded-full bg-cyan-500 text-[8px] font-black text-white">
            ACTIVE
          </span>
        )}
      </button>

      {/* Shuffle Reroll */}
      <button
        type="button"
        disabled={disabled || powerups.rerolls <= 0}
        onClick={onReroll}
        className={`relative flex-1 py-1.5 sm:py-2 px-2 sm:px-2.5 rounded-xl border flex items-center justify-center gap-1 sm:gap-1.5 transition-all cursor-pointer touch-manipulation active:scale-95 ${
          powerups.rerolls > 0
            ? 'bg-slate-900/80 hover:bg-slate-800/90 border-purple-500/30 text-purple-300'
            : 'bg-slate-900/40 border-white/5 text-slate-600 cursor-not-allowed opacity-50'
        }`}
        title="Shuffle: Get 3 new block shapes"
        aria-label={`Shuffle shapes, ${powerups.rerolls} remaining`}
      >
        <RefreshCw className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-purple-400" />
        <span className="text-[11px] sm:text-xs font-bold">Reroll</span>
        <span className="ml-auto px-1.5 py-0.2 rounded-full bg-purple-500/20 text-[10px] font-black tabular-nums border border-purple-500/30">
          {powerups.rerolls}
        </span>
      </button>

      {/* Cancel active tool button */}
      {activeTool !== 'none' && (
        <button
          type="button"
          onClick={() => onSelectTool('none')}
          title="Cancel active booster"
          className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border border-white/10 transition-all cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
};
