import React from 'react';
import { Play, RotateCcw, Home } from 'lucide-react';

interface PauseModalProps {
  isOpen: boolean;
  score: number;
  bestScore: number;
  onResume: () => void;
  onRestart: () => void;
  onTitle: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  isOpen,
  score,
  bestScore,
  onResume,
  onRestart,
  onTitle,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-pop-in">
      <div className="relative w-full max-w-xs max-h-[92dvh] overflow-y-auto p-5 sm:p-6 rounded-3xl bg-[#141530] border-2 border-purple-500/30 shadow-2xl text-white text-center flex flex-col items-center">
        <h2 className="font-display font-black text-2xl tracking-wider text-amber-300">
          GAME PAUSED
        </h2>
        <p className="text-xs text-slate-400 mt-1 mb-4">
          Take a breath, then continue your streak!
        </p>

        {/* Score Readouts */}
        <div className="flex justify-around w-full p-2.5 rounded-xl bg-slate-900/60 border border-white/5 mb-5 text-center">
          <div>
            <div className="text-[10px] text-cyan-400 font-bold uppercase">SCORE</div>
            <div className="font-display font-black text-xl tabular-nums">{score}</div>
          </div>
          <div className="w-px h-8 bg-white/10" />
          <div>
            <div className="text-[10px] text-amber-400 font-bold uppercase">BEST</div>
            <div className="font-display font-black text-xl tabular-nums text-amber-300">{bestScore}</div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5 w-full">
          <button
            type="button"
            onClick={onResume}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-display font-bold text-base flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95"
          >
            <Play className="w-5 h-5 fill-slate-950" />
            <span>RESUME</span>
          </button>

          <button
            type="button"
            onClick={onRestart}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95"
          >
            <RotateCcw className="w-4 h-4 text-cyan-400" />
            <span>RESTART GAME</span>
          </button>

          <button
            type="button"
            onClick={onTitle}
            className="w-full py-2.5 px-4 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <Home className="w-4 h-4" />
            <span>MAIN MENU</span>
          </button>
        </div>
      </div>
    </div>
  );
};
