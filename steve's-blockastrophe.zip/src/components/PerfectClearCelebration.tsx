import React, { useEffect, useState } from 'react';
import { Sparkles, Trophy, Star } from 'lucide-react';

interface PerfectClearCelebrationProps {
  onComplete: () => void;
}

export const PerfectClearCelebration: React.FC<PerfectClearCelebrationProps> = ({ onComplete }) => {
  const [displayBonus, setDisplayBonus] = useState(0);

  useEffect(() => {
    // Score counter animation: 0 -> 10,000 over 1.6s
    const startTime = performance.now();
    const duration = 1600;
    const targetBonus = 10000;

    let animId: number;
    const updateCounter = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(1, elapsed / duration);
      // Ease-out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayBonus(Math.floor(eased * targetBonus));

      if (progress < 1) {
        animId = requestAnimationFrame(updateCounter);
      } else {
        setDisplayBonus(targetBonus);
      }
    };

    animId = requestAnimationFrame(updateCounter);

    // End celebration after 2.8s total
    const timer = setTimeout(() => {
      onComplete();
    }, 2800);

    return () => {
      cancelAnimationFrame(animId);
      clearTimeout(timer);
    };
  }, [onComplete]);

  // Generate 24 floating sparkles/confetti pieces
  const confettiParticles = Array.from({ length: 28 }).map((_, i) => {
    const angle = (i / 28) * 360;
    const distance = 80 + (i % 6) * 45;
    const color = [
      '#ffd700',
      '#ff007f',
      '#00f5d4',
      '#b827fc',
      '#ff7700',
      '#38ef7d',
      '#00d2ff',
    ][i % 7];
    const size = 6 + (i % 4) * 3;
    const delay = (i % 7) * 0.08;

    return (
      <span
        key={i}
        className="absolute rounded-full pointer-events-none animate-ping"
        style={{
          width: `${size}px`,
          height: `${size}px`,
          backgroundColor: color,
          boxShadow: `0 0 12px ${color}`,
          transform: `rotate(${angle}deg) translate(${distance}px)`,
          animationDuration: `${1.2 + (i % 4) * 0.3}s`,
          animationDelay: `${delay}s`,
        }}
      />
    );
  });

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Perfect Clear Celebration"
      className="fixed inset-0 z-50 flex flex-col items-center justify-center p-4 overflow-hidden pointer-events-auto bg-black/75 backdrop-blur-md animate-fade-in"
    >
      {/* Full-screen radiant gold pulse lightwave */}
      <div className="absolute inset-0 bg-radial from-amber-500/25 via-purple-600/10 to-transparent pointer-events-none animate-pulse" />

      {/* Screen flash wave */}
      <div className="absolute inset-0 bg-white/20 pointer-events-none animate-ping opacity-20" />

      {/* Rotating radial sunburst rays behind text */}
      <div className="absolute w-[500px] h-[500px] rounded-full bg-gradient-to-tr from-amber-400/20 via-pink-500/15 to-cyan-400/20 blur-3xl animate-spin pointer-events-none" style={{ animationDuration: '8s' }} />

      {/* Center Confetti blast */}
      <div className="relative flex items-center justify-center mb-6">
        {confettiParticles}

        {/* Golden Trophy Icon with Halo */}
        <div className="relative p-6 rounded-3xl bg-gradient-to-br from-amber-300 via-amber-500 to-yellow-600 shadow-[0_0_50px_rgba(251,191,36,0.8)] border-2 border-yellow-200 animate-bounce">
          <Trophy className="w-16 h-16 sm:w-20 sm:h-20 text-slate-950 drop-shadow-[0_2px_4px_rgba(255,255,255,0.4)]" />
          <Star className="absolute -top-3 -right-3 w-8 h-8 text-yellow-200 fill-yellow-200 animate-spin" style={{ animationDuration: '3s' }} />
          <Sparkles className="absolute -bottom-2 -left-2 w-7 h-7 text-amber-100 animate-pulse" />
        </div>
      </div>

      {/* PERFECT CLEAR Main Banner */}
      <div className="text-center space-y-2 z-10">
        <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-amber-400/20 border border-amber-300/40 text-amber-300 text-xs sm:text-sm font-black tracking-widest uppercase shadow-lg">
          <Sparkles className="w-4 h-4" /> Board Mastered
        </div>

        <h1 className="text-4xl sm:text-6xl font-black italic tracking-wider bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-500 bg-clip-text text-transparent drop-shadow-[0_4px_25px_rgba(245,158,11,0.9)] animate-pulse">
          PERFECT CLEAR!
        </h1>

        <p className="text-base sm:text-lg font-bold text-slate-200 tracking-wide drop-shadow-md">
          EVERY BLOCK OBLITERATED
        </p>
      </div>

      {/* +10,000 BONUS Counter Box */}
      <div className="mt-6 z-10 flex flex-col items-center">
        <div className="px-6 py-3 rounded-2xl bg-gradient-to-r from-purple-900/90 via-slate-900/90 to-purple-900/90 border-2 border-amber-400/80 shadow-[0_0_35px_rgba(251,191,36,0.6)] flex items-center gap-3">
          <span className="text-sm sm:text-base font-extrabold text-amber-300 tracking-wider">
            BONUS AWARDED
          </span>
          <span className="text-3xl sm:text-4xl font-black font-mono text-amber-300 tracking-tight">
            +{displayBonus.toLocaleString()}
          </span>
        </div>

        <div className="mt-4 flex items-center gap-2 text-xs font-semibold text-slate-400 animate-pulse">
          <span>Generating Next Board Stage...</span>
        </div>
      </div>
    </div>
  );
};
