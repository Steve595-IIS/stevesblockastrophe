import React from 'react';
import { Flame, Sparkles } from 'lucide-react';

interface FeverBarProps {
  charge: number; // 0 to 100
  isFeverActive: boolean;
  feverSecondsLeft: number;
}

export const FeverBar: React.FC<FeverBarProps> = ({
  charge,
  isFeverActive,
  feverSecondsLeft,
}) => {
  return (
    <div className="w-full max-w-md mx-auto px-2 py-0.5 z-10 select-none">
      <div
        className={`relative w-full h-6 rounded-full overflow-hidden p-0.5 border flex items-center transition-all ${
          isFeverActive
            ? 'bg-gradient-to-r from-amber-500/30 via-rose-500/30 to-purple-500/30 border-amber-400 ring-2 ring-amber-400/40 shadow-[0_0_20px_rgba(245,158,11,0.5)] animate-pulse'
            : 'bg-slate-900/80 border-white/10'
        }`}
      >
        {/* Progress fill */}
        <div
          className={`h-full rounded-full transition-all duration-300 ${
            isFeverActive
              ? 'w-full bg-gradient-to-r from-amber-400 via-rose-500 to-purple-600 animate-pulse'
              : 'bg-gradient-to-r from-cyan-500 via-teal-400 to-indigo-500'
          }`}
          style={{ width: isFeverActive ? '100%' : `${Math.min(100, charge)}%` }}
        />

        {/* Text overlay inside meter */}
        <div className="absolute inset-0 flex items-center justify-between px-3 text-[10px] font-black uppercase tracking-wider text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]">
          {isFeverActive ? (
            <>
              <div className="flex items-center gap-1 text-amber-200">
                <Flame className="w-3.5 h-3.5 fill-amber-300 text-amber-300 animate-bounce" />
                <span>FEVER MODE · 2X POINTS!</span>
              </div>
              <span className="tabular-nums text-white bg-black/40 px-1.5 py-0.2 rounded-full border border-amber-300/40">
                {feverSecondsLeft}s
              </span>
            </>
          ) : (
            <>
              <div className="flex items-center gap-1 text-slate-300">
                <Sparkles className="w-3 h-3 text-cyan-400" />
                <span>BLAST METER</span>
              </div>
              <span className="tabular-nums text-cyan-300 font-bold">{Math.round(charge)}%</span>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
