import React, { forwardRef, useState } from 'react';
import { ColorDef, GRID_SIZE, Piece, ThemeDef, canPlacePiece } from '../game/logic.ts';
import { ActiveTool } from './PowerupsBar.tsx';
import { Bomb, Zap } from 'lucide-react';

interface GameBoardProps {
  board: (ColorDef | null)[][];
  hoveredPlacement: { row: number; col: number; isValid: boolean } | null;
  activePiece: Piece | null;
  clearingRows: number[];
  clearingCols: number[];
  activeTool?: ActiveTool;
  theme?: ThemeDef;
  isFeverActive?: boolean;
  onCellClick?: (row: number, col: number) => void;
}

export const GameBoard = forwardRef<HTMLDivElement, GameBoardProps>(({
  board,
  hoveredPlacement,
  activePiece,
  clearingRows,
  clearingCols,
  activeTool = 'none',
  theme,
  isFeverActive = false,
  onCellClick,
}, ref) => {
  const [hoveredCell, setHoveredCell] = useState<{ r: number; c: number } | null>(null);

  // Ghost block placement preview
  const isGhostCell = (r: number, c: number): boolean => {
    if (activeTool !== 'none') return false;

    // Use dragged hover placement or hover over cell when a piece is selected
    const placement = hoveredPlacement || (
      activePiece && hoveredCell && canPlacePiece(board, activePiece.matrix, hoveredCell.r, hoveredCell.c)
        ? { row: hoveredCell.r, col: hoveredCell.c, isValid: true }
        : null
    );

    if (!placement || !activePiece || !placement.isValid) return false;
    const { row: startR, col: startC } = placement;
    const matrix = activePiece.matrix;

    const relR = r - startR;
    const relC = c - startC;

    if (relR >= 0 && relR < matrix.length && relC >= 0 && relC < matrix[0].length) {
      return matrix[relR][relC] === 1;
    }
    return false;
  };

  // Completed line clear animation
  const isClearingCell = (r: number, c: number): boolean => {
    return clearingRows.includes(r) || clearingCols.includes(c);
  };

  // Bomb target preview (3x3 area)
  const isBombTargetCell = (r: number, c: number): boolean => {
    if (activeTool !== 'bomb' || !hoveredCell) return false;
    return Math.abs(hoveredCell.r - r) <= 1 && Math.abs(hoveredCell.c - c) <= 1;
  };

  // Zap target preview (row)
  const isZapTargetCell = (r: number, c: number): boolean => {
    if (activeTool !== 'zap' || !hoveredCell) return false;
    return hoveredCell.r === r;
  };

  return (
    <div
      ref={ref}
      data-testid="game-board"
      className={`relative w-full max-w-[min(330px,42dvh)] sm:max-w-[380px] aspect-square p-2 sm:p-2.5 mx-auto rounded-2xl bg-gradient-to-b ${
        theme ? theme.boardBg : 'from-[#13142e] to-[#0c0d20]'
      } border-2 ${
        isFeverActive
          ? 'border-amber-400 ring-4 ring-amber-400/30 shadow-[0_0_35px_rgba(245,158,11,0.5)]'
          : theme
          ? theme.boardBorder
          : 'border-[#2b2d56]'
      } shadow-[0_15px_35px_rgba(0,0,0,0.6)] flex items-center justify-center select-none touch-none transition-all duration-300`}
    >
      {/* 8x8 CSS Grid */}
      <div className="grid grid-cols-8 grid-rows-8 gap-1 sm:gap-1.5 w-full h-full">
        {board.map((row, r) =>
          row.map((cellColor, c) => {
            const ghost = isGhostCell(r, c);
            const clearing = isClearingCell(r, c);
            const bombTarget = isBombTargetCell(r, c);
            const zapTarget = isZapTargetCell(r, c);
            const isCenterBomb = hoveredCell && hoveredCell.r === r && hoveredCell.c === c && activeTool === 'bomb';

            return (
              <button
                key={`${r}-${c}`}
                type="button"
                tabIndex={-1}
                aria-label={`Grid cell row ${r + 1} column ${c + 1}${cellColor ? ` occupied by ${cellColor.name}` : ' empty'}`}
                onPointerEnter={() => setHoveredCell({ r, c })}
                onPointerLeave={() => setHoveredCell(null)}
                onClick={() => onCellClick?.(r, c)}
                className={`relative w-full h-full rounded-lg sm:rounded-xl transition-all duration-150 flex items-center justify-center cursor-pointer ${
                  cellColor
                    ? clearing
                      ? 'animate-line-flash z-20'
                      : 'block-tile z-10'
                    : ghost
                    ? 'block-tile-ghost z-10'
                    : bombTarget
                    ? 'bg-rose-950/70 border border-rose-500/80 shadow-[0_0_12px_rgba(244,63,94,0.6)] z-20'
                    : zapTarget
                    ? 'bg-cyan-950/70 border border-cyan-400/80 shadow-[0_0_12px_rgba(6,182,212,0.6)] z-20'
                    : 'grid-slot bg-[#070817]/90 border border-white/[0.04]'
                } ${bombTarget && cellColor ? 'ring-2 ring-rose-400 animate-pulse' : ''} ${
                  zapTarget && cellColor ? 'ring-2 ring-cyan-300 animate-pulse' : ''
                }`}
                style={{
                  background: cellColor
                    ? `linear-gradient(135deg, ${cellColor.fill}, ${cellColor.border})`
                    : ghost && activePiece
                    ? `${activePiece.color.fill}66`
                    : undefined,
                  boxShadow: cellColor && !clearing
                    ? `0 0 8px ${cellColor.glow}, inset 0 2px 3px rgba(255,255,255,0.4), inset 0 -2px 3px rgba(0,0,0,0.4)`
                    : ghost && activePiece
                    ? `0 0 10px ${activePiece.color.glow}, inset 0 0 4px #ffffff`
                    : undefined,
                  border: ghost && activePiece
                    ? `2px solid ${activePiece.color.fill}`
                    : undefined,
                }}
              >
                {/* Gloss highlight on occupied blocks */}
                {cellColor && !clearing && (
                  <span className="absolute top-0.5 left-0.5 right-0.5 h-[35%] rounded-[3px] bg-white/30 pointer-events-none" />
                )}

                {/* Pulsing beacon if ghost */}
                {ghost && (
                  <span className="w-2.5 h-2.5 rounded-full bg-white/80 animate-ping pointer-events-none" />
                )}

                {/* Center reticle icon for active tool */}
                {isCenterBomb && (
                  <Bomb className="w-5 h-5 text-rose-300 animate-bounce pointer-events-none drop-shadow-[0_0_8px_#ff0055]" />
                )}
                {zapTarget && c === 0 && (
                  <Zap className="w-4 h-4 text-cyan-300 animate-pulse pointer-events-none drop-shadow-[0_0_8px_#00ffff]" />
                )}
              </button>
            );
          })
        )}
      </div>
    </div>
  );
});

GameBoard.displayName = 'GameBoard';
