import React from 'react';
import { Piece } from '../game/logic.ts';

interface PieceTrayProps {
  pieces: (Piece | null)[];
  selectedPieceIndex: number | null;
  draggingPieceIndex: number | null;
  canFitMap: boolean[]; // whether piece at index can fit on board
  onSelectPiece: (index: number) => void;
  onPointerDownPiece: (index: number, e: React.PointerEvent<HTMLDivElement>) => void;
}

export const PieceTray: React.FC<PieceTrayProps> = ({
  pieces,
  selectedPieceIndex,
  draggingPieceIndex,
  canFitMap,
  onSelectPiece,
  onPointerDownPiece,
}) => {
  return (
    <div className="w-full max-w-md mx-auto px-2 py-0.5 flex flex-col items-center gap-0.5 z-10 select-none">
      {/* 3 Piece Slots */}
      <div className="grid grid-cols-3 gap-2 sm:gap-2.5 w-full h-20 sm:h-26">
        {pieces.map((piece, index) => {
          if (!piece) {
            return (
              <div
                key={`empty-slot-${index}`}
                className="w-full h-full rounded-2xl border-2 border-dashed border-white/5 bg-slate-900/20 flex items-center justify-center opacity-30"
              />
            );
          }

          const isSelected = selectedPieceIndex === index;
          const isDragging = draggingPieceIndex === index;
          const canFit = canFitMap[index] ?? true;

          const rows = piece.matrix.length;
          const cols = piece.matrix[0].length;

          return (
            <div
              key={piece.id}
              role="button"
              tabIndex={0}
              aria-label={`Select block piece ${piece.name}, ${piece.color.name}, ${piece.cellCount} blocks${!canFit ? ' (cannot fit currently)' : ''}`}
              onClick={() => onSelectPiece(index)}
              onPointerDown={(e) => onPointerDownPiece(index, e)}
              className={`relative w-full h-full rounded-2xl p-1.5 sm:p-2 flex items-center justify-center cursor-grab active:cursor-grabbing touch-none transition-all duration-200 select-none ${
                isSelected
                  ? 'bg-purple-950/40 border-2 border-cyan-400 ring-4 ring-cyan-500/20 shadow-[0_0_20px_rgba(0,210,255,0.3)] scale-105'
                  : 'bg-[#101127]/90 hover:bg-[#161836] border border-white/10 shadow-[0_8px_20px_rgba(0,0,0,0.4)] hover:border-white/20'
              } ${isDragging ? 'opacity-20 scale-90' : 'opacity-100'} ${
                !canFit ? 'grayscale-[0.6] opacity-75' : ''
              }`}
            >
              {/* Mini Matrix Preview */}
              <div
                className="grid gap-1 items-center justify-center pointer-events-none"
                style={{
                  gridTemplateRows: `repeat(${rows}, minmax(0, 1fr))`,
                  gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
                  maxWidth: '85%',
                  maxHeight: '85%',
                }}
              >
                {piece.matrix.map((row, r) =>
                  row.map((val, c) =>
                    val === 1 ? (
                      <div
                        key={`tray-${r}-${c}`}
                        className="w-3.5 h-3.5 sm:w-4.5 sm:h-4.5 rounded-[3px] sm:rounded-[4px] block-tile relative"
                        style={{
                          background: `linear-gradient(135deg, ${piece.color.fill}, ${piece.color.border})`,
                          boxShadow: `0 0 6px ${piece.color.glow}, inset 0 1.5px 2px rgba(255,255,255,0.4), inset 0 -1.5px 2px rgba(0,0,0,0.35)`,
                        }}
                      >
                        <span className="absolute top-0.5 left-0.5 right-0.5 h-[35%] rounded-[2px] bg-white/35 pointer-events-none" />
                      </div>
                    ) : (
                      <div key={`tray-empty-${r}-${c}`} className="w-3.5 h-3.5 sm:w-4.5 sm:h-4.5" />
                    )
                  )
                )}
              </div>

              {/* Dim indicator if shape can't fit */}
              {!canFit && (
                <span className="absolute bottom-1 px-1.5 py-0.5 rounded text-[9px] font-bold tracking-tight bg-rose-950/80 text-rose-300 border border-rose-500/30">
                  No Fit
                </span>
              )}

              {/* Selected badge */}
              {isSelected && (
                <span className="absolute -top-1.5 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-cyan-400 text-slate-950 shadow-md">
                  Active
                </span>
              )}
            </div>
          );
        })}
      </div>

      {/* Instruction text */}
      <p className="text-[10px] sm:text-[11px] text-slate-400 font-medium tracking-wide mt-0.5 text-center">
        Drag shape or tap to select & place on 8x8 board
      </p>
    </div>
  );
};
