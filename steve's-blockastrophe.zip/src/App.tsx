/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ColorDef,
  GRID_SIZE,
  Piece,
  createEmptyBoard,
  generateRandomPieces,
  canPlacePiece,
  placePiece,
  findCompletedLines,
  clearCompletedLines,
  canPieceFitAnywhere,
  hasValidMoves,
  calculateMoveScore,
  GameMode,
  ThemeId,
  THEMES,
  PowerupsState,
  INITIAL_POWERUPS,
  executeBomb,
  executeLineZap,
  calculateFeverCharge,
  isBoardCompletelyEmpty,
  generatePreFilledBoard,
} from './game/logic.ts';
import { sound } from './game/audio.ts';
import { ParticleManager } from './game/particles.ts';
import { TitleScreen } from './components/TitleScreen.tsx';
import { HeaderHUD } from './components/HeaderHUD.tsx';
import { GameBoard } from './components/GameBoard.tsx';
import { PieceTray } from './components/PieceTray.tsx';
import { ComboBanner } from './components/ComboBanner.tsx';
import { GameOverModal } from './components/GameOverModal.tsx';
import { SettingsModal } from './components/SettingsModal.tsx';
import { PauseModal } from './components/PauseModal.tsx';
import { PowerupsBar, ActiveTool } from './components/PowerupsBar.tsx';
import { FeverBar } from './components/FeverBar.tsx';
import { PerfectClearCelebration } from './components/PerfectClearCelebration.tsx';

type GameState = 'title' | 'playing' | 'paused' | 'gameover';

const triggerHaptic = (pattern: number | number[]) => {
  try {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate(pattern);
    }
  } catch {}
};

export default function App() {
  // Query param autostart check
  const [gameState, setGameState] = useState<GameState>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1') {
        return 'playing';
      }
    }
    return 'title';
  });

  // Game Mode & Theme
  const [gameMode, setGameMode] = useState<GameMode>('classic');
  const [blitzTimeLeft, setBlitzTimeLeft] = useState<number>(60);
  const [themeId, setThemeId] = useState<ThemeId>(() => {
    try {
      const stored = localStorage.getItem('blockastrophe_theme') || localStorage.getItem('colorblast_theme');
      if (stored && (stored in THEMES)) return stored as ThemeId;
    } catch {}
    return 'cyberpunk';
  });

  // Core Game State
  const [pieces, setPieces] = useState<(Piece | null)[]>(() => generateRandomPieces(3));
  const [board, setBoard] = useState<(ColorDef | null)[][]>(() => {
    const initPieces = generateRandomPieces(3);
    return generatePreFilledBoard(GRID_SIZE, initPieces);
  });
  const [score, setScore] = useState<number>(0);
  const [linesCleared, setLinesCleared] = useState<number>(0);
  const [comboStreak, setComboStreak] = useState<number>(0);
  const [bestScore, setBestScore] = useState<number>(() => {
    try {
      const stored = localStorage.getItem('blockastrophe_best_score') || localStorage.getItem('colorblast_best_score');
      return stored ? parseInt(stored, 10) : 0;
    } catch {
      return 0;
    }
  });

  // Boosters & Fever Meter
  const [powerups, setPowerups] = useState<PowerupsState>(INITIAL_POWERUPS);
  const [activeTool, setActiveTool] = useState<ActiveTool>('none');
  const [feverCharge, setFeverCharge] = useState<number>(0);
  const [isFeverActive, setIsFeverActive] = useState<boolean>(false);
  const [feverSecondsLeft, setFeverSecondsLeft] = useState<number>(10);
  const [isPerfectClearCelebration, setIsPerfectClearCelebration] = useState<boolean>(false);

  // UI & Feedback State
  const [selectedPieceIndex, setSelectedPieceIndex] = useState<number | null>(null);
  const [draggingPieceIndex, setDraggingPieceIndex] = useState<number | null>(null);
  const [floatingPos, setFloatingPos] = useState<{ x: number; y: number } | null>(null);
  const [hoveredPlacement, setHoveredPlacement] = useState<{
    row: number;
    col: number;
    isValid: boolean;
  } | null>(null);

  const [clearingRows, setClearingRows] = useState<number[]>([]);
  const [clearingCols, setClearingCols] = useState<number[]>([]);
  const [comboBanner, setComboBanner] = useState<{
    tier: string;
    points: number;
    streak: number;
    visible: boolean;
  }>({ tier: '', points: 0, streak: 0, visible: false });

  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(() => !sound.getSoundEnabled());
  const [isMusicEnabled, setIsMusicEnabled] = useState<boolean>(() => sound.getMusicEnabled());
  const [isNewBest, setIsNewBest] = useState<boolean>(false);

  // References
  const boardRef = useRef<HTMLDivElement>(null);
  const particleCanvasRef = useRef<HTMLCanvasElement>(null);
  const particleManagerRef = useRef<ParticleManager | null>(null);

  // Drag tracking refs
  const isPointerDownRef = useRef<boolean>(false);
  const activePieceIndexRef = useRef<number | null>(null);
  const dragTouchOffsetRef = useRef<number>(0);
  const pointerStartPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const hasMovedPastThresholdRef = useRef<boolean>(false);

  // Current theme object
  const currentTheme = THEMES[themeId] || THEMES.cyberpunk;

  // Sync document body state for testing & accessibility
  useEffect(() => {
    document.body.dataset.state = gameState;
  }, [gameState]);

  // Dev hook to trigger Perfect Clear celebration
  useEffect(() => {
    (window as any).__trigger_pc = () => {
      setIsPerfectClearCelebration(true);
      sound.playPerfectClear();
    };
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('test_perfect_clear') === '1') {
        setIsPerfectClearCelebration(true);
      }
    }
  }, []);

  // Attach particle canvas
  useEffect(() => {
    if (particleCanvasRef.current) {
      const pm = new ParticleManager();
      pm.attach(particleCanvasRef.current);
      particleManagerRef.current = pm;

      const handleResize = () => pm.resize();
      window.addEventListener('resize', handleResize);
      return () => {
        window.removeEventListener('resize', handleResize);
        pm.detach();
      };
    }
  }, []);

  // Blitz mode countdown timer
  useEffect(() => {
    if (gameState !== 'playing' || gameMode !== 'blitz') return;

    const timer = setInterval(() => {
      setBlitzTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          sound.playGameOver();
          setGameState('gameover');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [gameState, gameMode]);

  // Fever mode countdown timer
  useEffect(() => {
    if (!isFeverActive || gameState !== 'playing') return;

    const interval = setInterval(() => {
      setFeverSecondsLeft(prev => {
        if (prev <= 1) {
          setIsFeverActive(false);
          setFeverCharge(0);
          return 10;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isFeverActive, gameState]);

  // Compute fit map for available pieces
  const canFitMap = pieces.map(piece => {
    if (!piece) return false;
    return canPieceFitAnywhere(board, piece);
  });

  // Cycle theme handler
  const handleCycleTheme = useCallback(() => {
    const themeKeys: ThemeId[] = ['cyberpunk', 'candypop', 'retro', 'crystal'];
    const currentIdx = themeKeys.indexOf(themeId);
    const nextTheme = themeKeys[(currentIdx + 1) % themeKeys.length];
    setThemeId(nextTheme);
    try {
      localStorage.setItem('blockastrophe_theme', nextTheme);
    } catch {}
  }, [themeId]);

  // Restart game handler
  const handleRestart = useCallback(() => {
    const freshPieces = generateRandomPieces(3);
    const prefilled = generatePreFilledBoard(GRID_SIZE, freshPieces);
    setBoard(prefilled);
    setPieces(freshPieces);
    setScore(0);
    setLinesCleared(0);
    setComboStreak(0);
    setBlitzTimeLeft(60);
    setFeverCharge(0);
    setIsFeverActive(false);
    setFeverSecondsLeft(10);
    setPowerups(INITIAL_POWERUPS);
    setActiveTool('none');
    setSelectedPieceIndex(null);
    setDraggingPieceIndex(null);
    setFloatingPos(null);
    setHoveredPlacement(null);
    setClearingRows([]);
    setClearingCols([]);
    setIsNewBest(false);
    setIsPerfectClearCelebration(false);
    setGameState('playing');
    sound.playStart();
  }, []);

  // Check game over
  const checkGameOverCondition = useCallback((currentBoard: (ColorDef | null)[][], currentPieces: (Piece | null)[]) => {
    const activeRemaining = currentPieces.filter((p): p is Piece => p !== null);
    if (activeRemaining.length === 0) return; // Will be replenished

    const hasMoves = hasValidMoves(currentBoard, activeRemaining);
    if (!hasMoves) {
      setTimeout(() => {
        sound.playGameOver();
        triggerHaptic([50, 30, 80]);
        setGameState('gameover');
      }, 550);
    }
  }, []);

  // Handle Perfect Clear celebration finished: advance to fresh pre-filled stage
  const handlePerfectClearComplete = useCallback(() => {
    setIsPerfectClearCelebration(false);
    const activeRemaining = pieces.filter((p): p is Piece => p !== null);
    const piecesForGen = activeRemaining.length > 0 ? activeRemaining : generateRandomPieces(3);
    const nextBoard = generatePreFilledBoard(GRID_SIZE, piecesForGen);
    setBoard(nextBoard);
    checkGameOverCondition(nextBoard, pieces);
  }, [pieces, checkGameOverCondition]);

  // Execute placement on board
  const executePlacement = useCallback((pieceIndex: number, targetRow: number, targetCol: number) => {
    const piece = pieces[pieceIndex];
    if (!piece) return;

    if (!canPlacePiece(board, piece.matrix, targetRow, targetCol)) {
      sound.playInvalid();
      return;
    }

    // Sound and visual snap
    sound.playSnap();
    triggerHaptic(20);

    // 1. Place piece
    const newBoard = placePiece(board, piece, targetRow, targetCol);

    // Spawn placement particles
    if (boardRef.current && particleManagerRef.current) {
      const rect = boardRef.current.getBoundingClientRect();
      const cellSize = rect.width / GRID_SIZE;
      for (let r = 0; r < piece.matrix.length; r++) {
        for (let c = 0; c < piece.matrix[r].length; c++) {
          if (piece.matrix[r][c] === 1) {
            const cellX = rect.left + (targetCol + c + 0.5) * cellSize;
            const cellY = rect.top + (targetRow + r + 0.5) * cellSize;
            particleManagerRef.current.spawnBurst(cellX, cellY, piece.color.fill, 6, 0.6);
          }
        }
      }
    }

    // 2. Consume piece from tray
    const nextPieces = [...pieces];
    nextPieces[pieceIndex] = null;

    // Replenish if all 3 used
    const allUsed = nextPieces.every(p => p === null);
    const finalPieces = allUsed ? generateRandomPieces(3) : nextPieces;

    // 3. Check line completions
    const completed = findCompletedLines(newBoard);
    const totalLines = completed.rows.length + completed.cols.length;

    // 4. Update Fever Meter Charge
    if (!isFeverActive) {
      const feverResult = calculateFeverCharge(feverCharge, piece.cellCount, totalLines);
      if (feverResult.shouldTriggerFever) {
        setIsFeverActive(true);
        setFeverSecondsLeft(10);
        sound.playFever();
        triggerHaptic([30, 20, 30, 20, 50]);
        if (boardRef.current && particleManagerRef.current) {
          const rect = boardRef.current.getBoundingClientRect();
          particleManagerRef.current.spawnBurst(rect.left + rect.width / 2, rect.top + rect.height / 2, '#ffd700', 30, 2);
        }
      } else {
        setFeverCharge(feverResult.nextCharge);
      }
    }

    // Blitz bonus time (+3s per line, +6s for combo)
    if (gameMode === 'blitz' && totalLines > 0) {
      setBlitzTimeLeft(prev => Math.min(120, prev + totalLines * 3 + (totalLines >= 2 ? 3 : 0)));
    }

    // Award bonus boosters for high performance
    if (totalLines >= 2) {
      setPowerups(prev => ({ ...prev, bombs: Math.min(3, prev.bombs + 1) }));
    }
    const currentLinesTotal = linesCleared + totalLines;
    if (totalLines > 0 && Math.floor(currentLinesTotal / 5) > Math.floor(linesCleared / 5)) {
      setPowerups(prev => ({ ...prev, zaps: Math.min(3, prev.zaps + 1) }));
    }

    if (totalLines > 0) {
      // Line clear detected!
      setClearingRows(completed.rows);
      setClearingCols(completed.cols);

      const nextStreak = comboStreak + 1;
      setComboStreak(nextStreak);

      const scoreInfo = calculateMoveScore(piece.cellCount, totalLines, nextStreak);
      // Double points during Fever!
      const pointsMultiplier = isFeverActive ? 2 : 1;
      const pointsToAward = scoreInfo.totalAwarded * pointsMultiplier;

      const newScore = score + pointsToAward;
      setScore(newScore);
      setLinesCleared(prev => prev + totalLines);

      // Best score check
      if (newScore > bestScore) {
        setBestScore(newScore);
        setIsNewBest(true);
        try {
          localStorage.setItem('blockastrophe_best_score', String(newScore));
        } catch {}
      }

      // Audio & Particle FX
      sound.playLineClear(totalLines, nextStreak);
      triggerHaptic([30, 25, 45]);

      if (boardRef.current && particleManagerRef.current) {
        const rect = boardRef.current.getBoundingClientRect();
        const cellSize = rect.width / GRID_SIZE;

        // Particle bursts along cleared rows
        completed.rows.forEach(r => {
          for (let c = 0; c < GRID_SIZE; c += 2) {
            const px = rect.left + (c + 0.5) * cellSize;
            const py = rect.top + (r + 0.5) * cellSize;
            particleManagerRef.current?.spawnBurst(px, py, '#ffffff', 10, 1.2);
            particleManagerRef.current?.spawnBurst(px, py, piece.color.fill, 10, 1.2);
          }
        });

        // Particle bursts along cleared columns
        completed.cols.forEach(c => {
          for (let r = 0; r < GRID_SIZE; r += 2) {
            const px = rect.left + (c + 0.5) * cellSize;
            const py = rect.top + (r + 0.5) * cellSize;
            particleManagerRef.current?.spawnBurst(px, py, '#ffffff', 10, 1.2);
            particleManagerRef.current?.spawnBurst(px, py, piece.color.fill, 10, 1.2);
          }
        });
      }

      // Show combo banner for multi-line or high streak
      if (totalLines >= 2 || nextStreak >= 2 || isFeverActive) {
        setComboBanner({
          tier: isFeverActive ? `2X ${scoreInfo.comboTier || 'COMBO!'}` : scoreInfo.comboTier,
          points: scoreInfo.clearPoints * pointsMultiplier,
          streak: nextStreak,
          visible: true,
        });
        setTimeout(() => {
          setComboBanner(prev => ({ ...prev, visible: false }));
        }, 1200);
      }

      // Delay clearing board state to let the flash animation complete
      setTimeout(() => {
        const clearedBoard = clearCompletedLines(newBoard, completed);
        setBoard(clearedBoard);
        setClearingRows([]);
        setClearingCols([]);
        setPieces(finalPieces);

        // Check for PERFECT CLEAR: all 64 cells on the 8x8 board are empty!
        if (isBoardCompletelyEmpty(clearedBoard)) {
          const perfectClearBonus = 10000;
          setScore(prev => {
            const nextScore = prev + perfectClearBonus;
            if (nextScore > bestScore) {
              setBestScore(nextScore);
              setIsNewBest(true);
              try {
                localStorage.setItem('blockastrophe_best_score', String(nextScore));
              } catch {}
            }
            return nextScore;
          });

          // Play fanfare audio
          sound.playPerfectClear();
          triggerHaptic([50, 40, 50, 40, 80]);

          // Spawn celebratory full-board golden and rainbow particles
          if (boardRef.current && particleManagerRef.current) {
            const rect = boardRef.current.getBoundingClientRect();
            particleManagerRef.current.spawnBurst(rect.left + rect.width / 2, rect.top + rect.height / 2, '#ffd700', 45, 2.5);
            particleManagerRef.current.spawnBurst(rect.left + rect.width / 4, rect.top + rect.height / 4, '#ff007f', 30, 2.0);
            particleManagerRef.current.spawnBurst(rect.left + (rect.width * 3) / 4, rect.top + rect.height / 4, '#00d2ff', 30, 2.0);
            particleManagerRef.current.spawnBurst(rect.left + rect.width / 2, rect.top + (rect.height * 3) / 4, '#b827fc', 30, 2.0);
          }

          // Trigger celebratory full-screen event
          setIsPerfectClearCelebration(true);
        } else {
          checkGameOverCondition(clearedBoard, finalPieces);
        }
      }, 320);
    } else {
      // No lines cleared
      setComboStreak(0);
      const scoreInfo = calculateMoveScore(piece.cellCount, 0, 0);
      const pointsMultiplier = isFeverActive ? 2 : 1;
      const newScore = score + scoreInfo.totalAwarded * pointsMultiplier;
      setScore(newScore);

      if (newScore > bestScore) {
        setBestScore(newScore);
        setIsNewBest(true);
        try {
          localStorage.setItem('blockastrophe_best_score', String(newScore));
          localStorage.setItem('colorblast_best_score', String(newScore));
        } catch {}
      }

      setBoard(newBoard);
      setPieces(finalPieces);
      checkGameOverCondition(newBoard, finalPieces);
    }

    // Reset interactions
    setSelectedPieceIndex(null);
    setDraggingPieceIndex(null);
    setFloatingPos(null);
    setHoveredPlacement(null);
  }, [board, pieces, comboStreak, score, bestScore, linesCleared, isFeverActive, feverCharge, gameMode, checkGameOverCondition]);

  // Execute 💣 Bomb Booster
  const handleExecuteBomb = useCallback((centerRow: number, centerCol: number) => {
    if (powerups.bombs <= 0) return;

    sound.playBomb();
    triggerHaptic([40, 25, 60]);
    const { newBoard, clearedPositions } = executeBomb(board, centerRow, centerCol);
    setBoard(newBoard);
    setPowerups(prev => ({ ...prev, bombs: Math.max(0, prev.bombs - 1) }));
    setActiveTool('none');

    // Spawn massive explosion particles
    if (boardRef.current && particleManagerRef.current) {
      const rect = boardRef.current.getBoundingClientRect();
      const cellSize = rect.width / GRID_SIZE;
      clearedPositions.forEach(pos => {
        const px = rect.left + (pos.col + 0.5) * cellSize;
        const py = rect.top + (pos.row + 0.5) * cellSize;
        particleManagerRef.current?.spawnBurst(px, py, '#ff3366', 12, 1.4);
        particleManagerRef.current?.spawnBurst(px, py, '#ffd700', 8, 1.2);
      });
    }

    setScore(prev => prev + clearedPositions.length * 2);

    if (isBoardCompletelyEmpty(newBoard)) {
      setScore(prev => prev + 10000);
      sound.playPerfectClear();
      triggerHaptic([50, 40, 50, 40, 80]);
      setIsPerfectClearCelebration(true);
    } else {
      checkGameOverCondition(newBoard, pieces);
    }
  }, [board, powerups.bombs, pieces, checkGameOverCondition]);

  // Execute ⚡ Laser Line Zap
  const handleExecuteZap = useCallback((row: number) => {
    if (powerups.zaps <= 0) return;

    sound.playZap();
    triggerHaptic([25, 20, 35]);
    const { newBoard, clearedPositions } = executeLineZap(board, 'row', row);
    setBoard(newBoard);
    setPowerups(prev => ({ ...prev, zaps: Math.max(0, prev.zaps - 1) }));
    setActiveTool('none');

    // Spawn laser beam particles
    if (boardRef.current && particleManagerRef.current) {
      const rect = boardRef.current.getBoundingClientRect();
      const cellSize = rect.width / GRID_SIZE;
      for (let c = 0; c < GRID_SIZE; c++) {
        const px = rect.left + (c + 0.5) * cellSize;
        const py = rect.top + (row + 0.5) * cellSize;
        particleManagerRef.current?.spawnBurst(px, py, '#00d2ff', 12, 1.3);
      }
    }

    setScore(prev => prev + 15);
    setLinesCleared(prev => prev + 1);

    if (isBoardCompletelyEmpty(newBoard)) {
      setScore(prev => prev + 10000);
      sound.playPerfectClear();
      triggerHaptic([50, 40, 50, 40, 80]);
      setIsPerfectClearCelebration(true);
    } else {
      checkGameOverCondition(newBoard, pieces);
    }
  }, [board, powerups.zaps, pieces, checkGameOverCondition]);

  // Execute 🔄 Reroll Shuffle
  const handleReroll = useCallback(() => {
    if (powerups.rerolls <= 0) return;

    sound.playReroll();
    triggerHaptic(15);
    const freshPieces = generateRandomPieces(3);
    setPieces(freshPieces);
    setPowerups(prev => ({ ...prev, rerolls: Math.max(0, prev.rerolls - 1) }));
    setSelectedPieceIndex(null);
  }, [powerups.rerolls]);

  // Calculate target grid coordinate from client pointer coordinates
  const calculateBoardCoordinates = useCallback((clientX: number, clientY: number, piece: Piece) => {
    if (!boardRef.current) return null;
    const rect = boardRef.current.getBoundingClientRect();

    // Check if pointer is near board bounds
    const margin = 45;
    if (
      clientX < rect.left - margin ||
      clientX > rect.right + margin ||
      clientY < rect.top - margin ||
      clientY > rect.bottom + margin
    ) {
      return null;
    }

    const padding = 10;
    const innerWidth = rect.width - padding * 2;
    const cellSize = innerWidth / GRID_SIZE;

    // Center the piece around the pointer
    const pieceWidthPx = piece.matrix[0].length * cellSize;
    const pieceHeightPx = piece.matrix.length * cellSize;

    const pieceTopLeftX = clientX - pieceWidthPx / 2;
    const pieceTopLeftY = clientY - pieceHeightPx / 2;

    const targetCol = Math.round((pieceTopLeftX - (rect.left + padding)) / cellSize);
    const targetRow = Math.round((pieceTopLeftY - (rect.top + padding)) / cellSize);

    const isValid = canPlacePiece(board, piece.matrix, targetRow, targetCol);
    return { row: targetRow, col: targetCol, isValid };
  }, [board]);

  // Drag interaction start
  const handlePointerDownPiece = (index: number, e: React.PointerEvent<HTMLDivElement>) => {
    if (gameState !== 'playing') return;
    const piece = pieces[index];
    if (!piece) return;

    // Deactivate active powerup tool when picking up piece
    setActiveTool('none');

    isPointerDownRef.current = true;
    activePieceIndexRef.current = index;
    hasMovedPastThresholdRef.current = false;
    pointerStartPosRef.current = { x: e.clientX, y: e.clientY };

    const isTouch = e.pointerType === 'touch';
    dragTouchOffsetRef.current = isTouch ? -75 : 0;
  };

  // Global Pointer Move & Up listeners for smooth dragging outside element bounds
  useEffect(() => {
    const handleGlobalPointerMove = (e: PointerEvent) => {
      if (!isPointerDownRef.current || activePieceIndexRef.current === null) return;
      const pieceIdx = activePieceIndexRef.current;
      const piece = pieces[pieceIdx];
      if (!piece) return;

      const dx = e.clientX - pointerStartPosRef.current.x;
      const dy = e.clientY - pointerStartPosRef.current.y;
      const dist = Math.hypot(dx, dy);

      if (!hasMovedPastThresholdRef.current && dist > 7) {
        hasMovedPastThresholdRef.current = true;
        setDraggingPieceIndex(pieceIdx);
        setSelectedPieceIndex(pieceIdx);
        sound.playPickup();
        triggerHaptic(12);
      }

      if (hasMovedPastThresholdRef.current) {
        const currentX = e.clientX;
        const currentY = e.clientY + dragTouchOffsetRef.current;
        setFloatingPos({ x: currentX, y: currentY });

        const hover = calculateBoardCoordinates(currentX, currentY, piece);
        setHoveredPlacement(hover);
      }
    };

    const handleGlobalPointerUp = (e: PointerEvent) => {
      if (!isPointerDownRef.current) return;
      isPointerDownRef.current = false;
      const pieceIdx = activePieceIndexRef.current;
      activePieceIndexRef.current = null;

      if (pieceIdx === null) return;
      const piece = pieces[pieceIdx];
      if (!piece) return;

      if (hasMovedPastThresholdRef.current) {
        // Was dragging: attempt drop placement
        const currentX = e.clientX;
        const currentY = e.clientY + dragTouchOffsetRef.current;
        const hover = calculateBoardCoordinates(currentX, currentY, piece);

        if (hover && hover.isValid) {
          executePlacement(pieceIdx, hover.row, hover.col);
        } else {
          sound.playInvalid();
        }

        setDraggingPieceIndex(null);
        setFloatingPos(null);
        setHoveredPlacement(null);
        hasMovedPastThresholdRef.current = false;
      } else {
        // Was a tap/click selection!
        sound.playPickup();
        triggerHaptic(12);
        setSelectedPieceIndex(prev => (prev === pieceIdx ? null : pieceIdx));
        setDraggingPieceIndex(null);
        setFloatingPos(null);
        setHoveredPlacement(null);
      }
    };

    const handleGlobalPointerCancel = () => {
      isPointerDownRef.current = false;
      activePieceIndexRef.current = null;
      hasMovedPastThresholdRef.current = false;
      setDraggingPieceIndex(null);
      setFloatingPos(null);
      setHoveredPlacement(null);
    };

    window.addEventListener('pointermove', handleGlobalPointerMove);
    window.addEventListener('pointerup', handleGlobalPointerUp);
    window.addEventListener('pointercancel', handleGlobalPointerCancel);

    return () => {
      window.removeEventListener('pointermove', handleGlobalPointerMove);
      window.removeEventListener('pointerup', handleGlobalPointerUp);
      window.removeEventListener('pointercancel', handleGlobalPointerCancel);
    };
  }, [pieces, calculateBoardCoordinates, executePlacement]);

  // Board cell click handler: places block, detonates bomb, or fires laser
  const handleCellClick = (row: number, col: number) => {
    if (gameState !== 'playing') return;

    // 1. If Bomb booster is active
    if (activeTool === 'bomb') {
      handleExecuteBomb(row, col);
      return;
    }

    // 2. If Zap booster is active
    if (activeTool === 'zap') {
      handleExecuteZap(row);
      return;
    }

    // 3. Regular piece placement in tap mode
    if (selectedPieceIndex === null) return;
    const piece = pieces[selectedPieceIndex];
    if (!piece) return;

    if (canPlacePiece(board, piece.matrix, row, col)) {
      executePlacement(selectedPieceIndex, row, col);
    } else {
      sound.playInvalid();
    }
  };

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Toggle sound
      if (e.key === 'm' || e.key === 'M') {
        const nextMute = !isMuted;
        setIsMuted(nextMute);
        sound.setSoundEnabled(!nextMute);
        return;
      }

      // Restart game
      if (e.key === 'r' || e.key === 'R') {
        if (gameState === 'playing' || gameState === 'paused') {
          handleRestart();
        }
        return;
      }

      // Quick booster shortcuts: 1 for Bomb, 2 for Zap, 3 for Reroll
      if (gameState === 'playing') {
        if (e.key === '1' && powerups.bombs > 0) {
          setActiveTool(prev => (prev === 'bomb' ? 'none' : 'bomb'));
          return;
        }
        if (e.key === '2' && powerups.zaps > 0) {
          setActiveTool(prev => (prev === 'zap' ? 'none' : 'zap'));
          return;
        }
        if (e.key === '3' && powerups.rerolls > 0) {
          handleReroll();
          return;
        }
      }

      // Pause / Esc
      if (e.key === 'Escape' || e.key === 'p' || e.key === 'P') {
        if (gameState === 'playing') {
          setGameState('paused');
        } else if (gameState === 'paused') {
          setGameState('playing');
        }
        return;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState, isMuted, powerups, handleRestart, handleReroll]);

  // Floating dragging piece representation
  const activeDragPiece = draggingPieceIndex !== null ? pieces[draggingPieceIndex] : null;

  return (
    <div className={`relative min-h-screen w-full flex flex-col justify-between items-center ${currentTheme.bgGradient} text-white overflow-hidden select-none touch-none transition-colors duration-500`}>
      {/* Particle Canvas Overlay */}
      <canvas
        ref={particleCanvasRef}
        data-testid="particle-canvas"
        className="fixed inset-0 w-full h-full pointer-events-none z-30"
      />

      {/* State: Title Screen */}
      {gameState === 'title' && (
        <TitleScreen
          bestScore={bestScore}
          selectedMode={gameMode}
          onSelectMode={setGameMode}
          onStart={(mode) => {
            setGameMode(mode);
            handleRestart();
            setGameState('playing');
          }}
          onOpenHowToPlay={() => setIsSettingsOpen(true)}
          isMuted={isMuted}
          onToggleMute={() => {
            const next = !isMuted;
            setIsMuted(next);
            sound.setSoundEnabled(!next);
          }}
        />
      )}

      {/* State: Playing or Paused */}
      {(gameState === 'playing' || gameState === 'paused' || gameState === 'gameover') && (
        <div className="relative w-full max-w-md h-[100dvh] max-h-screen flex flex-col justify-between items-center px-2 sm:px-3 pt-[max(0.25rem,env(safe-area-inset-top))] pb-[max(0.25rem,env(safe-area-inset-bottom))] z-10 overflow-hidden">
          {/* Header HUD */}
          <HeaderHUD
            score={score}
            bestScore={bestScore}
            linesCleared={linesCleared}
            comboStreak={comboStreak}
            gameMode={gameMode}
            blitzTimeLeft={blitzTimeLeft}
            theme={currentTheme}
            isMuted={isMuted}
            isMusicEnabled={isMusicEnabled}
            onToggleMute={() => {
              const next = !isMuted;
              setIsMuted(next);
              sound.setSoundEnabled(!next);
            }}
            onToggleMusic={() => {
              const next = !isMusicEnabled;
              setIsMusicEnabled(next);
              sound.setMusicEnabled(next);
            }}
            onCycleTheme={handleCycleTheme}
            onPause={() => setGameState('paused')}
            onRestart={() => {
              if (window.confirm('Restart game with a clean board?')) {
                handleRestart();
              }
            }}
            onOpenSettings={() => setIsSettingsOpen(true)}
          />

          {/* Fever / Blast Energy Meter */}
          <FeverBar
            charge={feverCharge}
            isFeverActive={isFeverActive}
            feverSecondsLeft={feverSecondsLeft}
          />

          {/* Main Board Container */}
          <main className="relative w-full flex items-center justify-center my-auto py-0.5 sm:py-1">
            <GameBoard
              ref={boardRef}
              board={board}
              hoveredPlacement={hoveredPlacement}
              activePiece={
                draggingPieceIndex !== null
                  ? pieces[draggingPieceIndex]
                  : selectedPieceIndex !== null
                  ? pieces[selectedPieceIndex]
                  : null
              }
              clearingRows={clearingRows}
              clearingCols={clearingCols}
              activeTool={activeTool}
              theme={currentTheme}
              isFeverActive={isFeverActive}
              onCellClick={handleCellClick}
            />

            {/* Combo Notification Banner */}
            <ComboBanner
              comboTier={comboBanner.tier}
              pointsAwarded={comboBanner.points}
              streakCount={comboBanner.streak}
              visible={comboBanner.visible}
            />
          </main>

          {/* Powerups & Boosters Bar */}
          <PowerupsBar
            powerups={powerups}
            activeTool={activeTool}
            onSelectTool={setActiveTool}
            onReroll={handleReroll}
            disabled={gameState !== 'playing'}
          />

          {/* Bottom Piece Tray */}
          <PieceTray
            pieces={pieces}
            selectedPieceIndex={selectedPieceIndex}
            draggingPieceIndex={draggingPieceIndex}
            canFitMap={canFitMap}
            onSelectPiece={() => {
              // Handled smoothly by unified pointer up handler
            }}
            onPointerDownPiece={handlePointerDownPiece}
          />
        </div>
      )}

      {/* Floating Ghost Piece while dragging */}
      {activeDragPiece && floatingPos && (
        <div
          className="fixed pointer-events-none z-50 transition-transform duration-75"
          style={{
            left: `${floatingPos.x}px`,
            top: `${floatingPos.y}px`,
            transform: 'translate(-50%, -50%) scale(1.1)',
            filter: 'drop-shadow(0 15px 25px rgba(0,0,0,0.7))',
          }}
        >
          <div
            className="grid gap-1 items-center justify-center"
            style={{
              gridTemplateRows: `repeat(${activeDragPiece.matrix.length}, minmax(0, 1fr))`,
              gridTemplateColumns: `repeat(${activeDragPiece.matrix[0].length}, minmax(0, 1fr))`,
            }}
          >
            {activeDragPiece.matrix.map((row, r) =>
              row.map((val, c) =>
                val === 1 ? (
                  <div
                    key={`floating-${r}-${c}`}
                    className="w-8 h-8 sm:w-9 sm:h-9 rounded-[6px] block-tile relative"
                    style={{
                      background: `linear-gradient(135deg, ${activeDragPiece.color.fill}, ${activeDragPiece.color.border})`,
                      boxShadow: `0 0 12px ${activeDragPiece.color.glow}, inset 0 2px 3px rgba(255,255,255,0.5), inset 0 -2px 3px rgba(0,0,0,0.4)`,
                    }}
                  >
                    <span className="absolute top-0.5 left-0.5 right-0.5 h-[35%] rounded-[3px] bg-white/40 pointer-events-none" />
                  </div>
                ) : (
                  <div key={`floating-empty-${r}-${c}`} className="w-8 h-8 sm:w-9 sm:h-9" />
                )
              )
            )}
          </div>
        </div>
      )}

      {/* State: Paused Modal */}
      <PauseModal
        isOpen={gameState === 'paused'}
        score={score}
        bestScore={bestScore}
        onResume={() => setGameState('playing')}
        onRestart={handleRestart}
        onTitle={() => setGameState('title')}
      />

      {/* State: Game Over Modal */}
      {gameState === 'gameover' && (
        <GameOverModal
          score={score}
          bestScore={bestScore}
          linesCleared={linesCleared}
          isNewBest={isNewBest}
          onRestart={handleRestart}
        />
      )}

      {/* Settings & How to Play Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        isMuted={isMuted}
        isMusicEnabled={isMusicEnabled}
        onToggleMute={() => {
          const next = !isMuted;
          setIsMuted(next);
          sound.setSoundEnabled(!next);
        }}
        onToggleMusic={() => {
          const next = !isMusicEnabled;
          setIsMusicEnabled(next);
          sound.setMusicEnabled(next);
        }}
        onRestart={() => {
          handleRestart();
          setIsSettingsOpen(false);
        }}
      />

      {/* Full Board Perfect Clear Celebration Modal */}
      {isPerfectClearCelebration && (
        <PerfectClearCelebration onComplete={handlePerfectClearComplete} />
      )}
    </div>
  );
}
